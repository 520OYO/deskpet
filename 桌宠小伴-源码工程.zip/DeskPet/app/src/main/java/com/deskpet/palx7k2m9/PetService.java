package com.deskpet.palx7k2m9;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.PixelFormat;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * 桌宠悬浮服务：把宠物画在屏幕上（其它应用之上），驱动动画、交互、息屏休眠。
 * 省电策略：屏幕熄灭时移除窗口并停止一切计算，亮屏再恢复。
 */
public class PetService extends Service implements PetView.Host {

    public static final String ACTION_REFRESH = "com.deskpet.palx7k2m9.REFRESH";
    public static final String ACTION_STOP = "com.deskpet.palx7k2m9.STOP";
    public static final String ACTION_CARE = "com.deskpet.palx7k2m9.CARE";
    public static final String CHANNEL_ID = "deskpet";

    private WindowManager wm;
    private Handler handler = new Handler();
    private ArrayList<PetView> views = new ArrayList<PetView>();
    private HashMap<PetView, WindowManager.LayoutParams> params = new HashMap<PetView, WindowManager.LayoutParams>();
    private HashMap<PetView, PetStore.Pet> pets = new HashMap<PetView, PetStore.Pet>();

    private boolean running = false;
    private boolean screenOn = true;
    private long screenOffAt = System.currentTimeMillis();
    private int sw = 1080, sh = 1920;
    private float density = 3f;

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private SensorEventListener shakeListener;
    private long lastShake = 0;
    private long lastBadgeEat = 0;
    private long lastSave = 0;
    private long lastChase = 0;

    private final Runnable loop = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            long now = SystemClock.uptimeMillis();
            for (PetView v : views) v.update(now);
            for (PetView v : views) syncWindow(v);
            tryBadgeEat(now);
            tryChase(now);
            trySave(now);
            handler.postDelayed(this, 28);   // ≈36fps，够流畅也省电
        }
    };

    private final BroadcastReceiver screenReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            String a = i.getAction();
            if (Intent.ACTION_SCREEN_OFF.equals(a)) {
                screenOn = false;
                screenOffAt = System.currentTimeMillis();
                pause();
            } else if (Intent.ACTION_SCREEN_ON.equals(a)) {
                screenOn = true;
                resume(true);
            } else if (Intent.ACTION_USER_PRESENT.equals(a)) {
                screenOn = true;
                resume(true);
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        measure();
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_SCREEN_OFF);
        f.addAction(Intent.ACTION_SCREEN_ON);
        f.addAction(Intent.ACTION_USER_PRESENT);
        registerReceiver(screenReceiver, f);
        setupShake();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String a = intent != null ? intent.getAction() : null;
        if (ACTION_STOP.equals(a)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        startForegroundCompat();
        measure();
        if (ACTION_CARE.equals(a)) {
            int type = intent.getIntExtra("type", 0);
            String tip = intent.getStringExtra("tip");
            doCare(type, tip);
            return START_STICKY;
        }
        if (views.isEmpty() || ACTION_REFRESH.equals(a) || !running) {
            buildPets();
        }
        if (!running) {
            running = true;
            handler.removeCallbacks(loop);
            handler.post(loop);
        }
        return START_STICKY;
    }


    /** 喂食 / 清洁 / 陪玩 */
    private void doCare(int type, String tip) {
        if (views.isEmpty()) {
            buildPets();
        }
        for (PetView v : views) {
            PetStore.Pet p = pets.get(v);
            if (p == null) continue;
            if (type == 0) {
                v.eat(tip != null ? tip : "好吃的");
                p.hunger = Math.min(100, p.hunger + 15);
            } else if (type == 1) {
                v.setState(PetArt.ST_PLAY);
                v.showBubble("洗香香~好舒服");
                p.clean = Math.min(100, p.clean + 18);
                p.mood = Math.min(100, p.mood + 5);
            } else {
                v.setState(PetArt.ST_DANCE);
                v.showBubble("陪我玩！");
                p.mood = Math.min(100, p.mood + 15);
            }
        }
        saveAll();
    }
    private void startForegroundCompat() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "桌宠运行中",
                    NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("桌面宠物正在陪伴你");
            if (nm != null) nm.createNotificationChannel(ch);
        }
        Intent it = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 20, it, PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder nb;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nb = new Notification.Builder(this, CHANNEL_ID);
        } else {
            nb = new Notification.Builder(this);
        }
        nb.setContentTitle("桌宠陪着你")
                .setContentText("点这里打开桌宠面板")
                .setSmallIcon(R.drawable.ic_stat_pet)
                .setContentIntent(pi)
                .setOngoing(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForeground(1001, nb.build());
        } else {
            startForeground(1001, nb.build());
        }
    }

    private void measure() {
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getMetrics(dm);
        sw = dm.widthPixels;
        sh = dm.heightPixels;
        density = dm.density;
    }

    private void buildPets() {
        clearViews();
        List<PetStore.Pet> list = PetStore.loadPets(this);
        if (list.isEmpty()) {
            PetStore.Pet p = new PetStore.Pet();
            p.id = "pet_" + System.currentTimeMillis();
            p.name = PetArt.nameOf(0);
            p.kind = 0;
            p.template = 0;
            p.relX = 0.5f;
            p.relY = 0.72f;
            list.add(p);
            PetStore.savePets(this, list);
        }
        for (PetStore.Pet p : list) {
            if (!p.enabled) continue;
            addPet(p);
        }
        running = true;
        handler.removeCallbacks(loop);
        handler.post(loop);
        if (!screenOn) pause();
    }

    private void addPet(PetStore.Pet p) {
        int win = (int) (p.sizeDp * density * 2.2f);
        PetView v = new PetView(this, this, p, win, win);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        lp.format = PixelFormat.TRANSLUCENT;
        lp.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
        lp.gravity = Gravity.TOP | Gravity.LEFT;
        lp.width = win;
        lp.height = win;
        lp.x = (int) (p.relX * sw - win / 2f);
        lp.y = (int) (p.relY * sh - win / 2f);
        lp.x = Math.max(-win / 3, Math.min(sw - win / 2, lp.x));
        lp.y = Math.max(0, Math.min(sh - win / 2, lp.y));
        try {
            wm.addView(v, lp);
        } catch (Exception e) {
            Toast.makeText(this, "需要悬浮窗权限", Toast.LENGTH_SHORT).show();
            return;
        }
        views.add(v);
        params.put(v, lp);
        pets.put(v, p);
    }

    private void clearViews() {
        for (PetView v : views) {
            try {
                wm.removeView(v);
            } catch (Exception e) {
                // ignore
            }
        }
        views.clear();
        params.clear();
        pets.clear();
    }

    private void syncWindow(PetView v) {
        WindowManager.LayoutParams lp = params.get(v);
        PetStore.Pet p = pets.get(v);
        if (lp == null || p == null) return;
        if (v.isDragging()) return;
        float cx = lp.width / 2f, cy = lp.height / 2f;
        float ox = v.getPx() - cx, oy = v.getPy() - cy;
        float th = lp.width * 0.16f;
        if (Math.abs(ox) > th || Math.abs(oy) > th) {
            int nx = Math.max(-lp.width / 3, Math.min(sw - lp.width * 2 / 3, lp.x + (int) ox));
            int ny = Math.max(0, Math.min(sh - lp.height * 2 / 3, lp.y + (int) oy));
            int movedX = nx - lp.x, movedY = ny - lp.y;
            if (movedX != 0 || movedY != 0) {
                lp.x = nx;
                lp.y = ny;
                try {
                    wm.updateViewLayout(v, lp);
                } catch (Exception e) {
                    return;
                }
            }
            // 屏幕上的绝对位置保持不变：窗口移动多少，内部坐标就回退多少
            v.setP(v.getPx() - movedX, v.getPy() - movedY);
            p.relX = (lp.x + v.getPx()) / (float) sw;
            p.relY = (lp.y + v.getPy()) / (float) sh;
        }
    }

    /** 每隔一段时间，让宠物互相追逐一会儿 */
    private void tryChase(long now) {
        if (views.size() < 2 || now - lastChase < 4000) return;
        lastChase = now;
        PetView a = views.get((int) (Math.random() * views.size()));
        PetView b = a;
        for (int i = 0; i < 4 && b == a; i++) b = views.get((int) (Math.random() * views.size()));
        if (a != b) a.chase(b);
    }

    /** 吞掉一条通知（角标数字随之消失） */
    private void tryBadgeEat(long now) {
        PetStore.Settings s = PetStore.getSettings(this);
        if (!s.eatBadge) return;
        if (now - lastBadgeEat < 7000) return;
        if (views.isEmpty()) return;
        int n = NotifEatService.pendingCount();
        if (n <= 0) return;
        lastBadgeEat = now;
        String what = NotifEatService.eatOne(this);
        PetView v = views.get((int) (Math.random() * views.size()));
        v.eat(what);
    }

    private void trySave(long now) {
        if (now - lastSave < 4000) return;
        lastSave = now;
        saveAll();
    }

    private void saveAll() {
        List<PetStore.Pet> list = PetStore.loadPets(this);
        for (PetStore.Pet p : list) {
            for (PetView v : views) {
                PetStore.Pet cur = pets.get(v);
                if (cur != null && cur.id != null && cur.id.equals(p.id)) {
                    p.relX = cur.relX;
                    p.relY = cur.relY;
                    p.mood = cur.mood;
                    p.hunger = cur.hunger;
                    p.clean = cur.clean;
                    p.lastCare = cur.lastCare;
                }
            }
        }
        PetStore.savePets(this, list);
    }

    private void pause() {
        running = false;
        handler.removeCallbacks(loop);
        for (PetView v : views) {
            try {
                wm.removeView(v);      // 熄屏彻底摘掉窗口，零开销
            } catch (Exception e) {
                // ignore
            }
        }
        if (sensorManager != null && shakeListener != null) {
            sensorManager.unregisterListener(shakeListener);
        }
        saveAll();
    }

    private void resume(boolean fake) {
        PetStore.Settings s = PetStore.getSettings(this);
        for (PetView v : views) {
            WindowManager.LayoutParams lp = params.get(v);
            if (lp == null) continue;
            try {
                wm.addView(v, lp);
            } catch (Exception e) {
                try {
                    wm.updateViewLayout(v, lp);
                } catch (Exception e2) {
                    // ignore
                }
            }
        }
        running = true;
        handler.removeCallbacks(loop);
        handler.post(loop);
        setupShake();

        // 离线衰减 + 伪造"它自己玩了一会儿"
        long away = System.currentTimeMillis() - screenOffAt;
        int mins = (int) (away / 60000);
        if (mins > 0) {
            for (PetView v : views) {
                PetStore.Pet p = pets.get(v);
                if (p == null) continue;
                p.mood = Math.max(0, p.mood - Math.min(20, mins / 3));
                p.hunger = Math.max(0, p.hunger - Math.min(25, mins / 2));
                p.clean = Math.max(0, p.clean - Math.min(15, mins / 5));
            }
        }
        if (fake && s.sleepOnScreenOff && !views.isEmpty() && away > 45000) {
            String[] lines = {"你回来啦！", "我刚刚自己玩了好久~", "睡得好香…", "偷偷跑了一圈回来",
                    "你不在我都在数星星", "刚打败了一只拖鞋"};
            views.get((int) (Math.random() * views.size()))
                    .fakeWake(lines[(int) (Math.random() * lines.length)]);
        }
        saveAll();
    }

    private void setupShake() {
        PetStore.Settings s = PetStore.getSettings(this);
        if (!s.shakeEnabled) return;
        if (sensorManager == null) {
            sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
            accelerometer = sensorManager != null ? sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) : null;
        }
        if (sensorManager == null || accelerometer == null) return;
        if (shakeListener != null) {
            sensorManager.unregisterListener(shakeListener);
        }
        shakeListener = new SensorEventListener() {
            private float lastX = 0, lastY = 0, lastZ = 0;

            @Override
            public void onSensorChanged(SensorEvent e) {
                float x = e.values[0], y = e.values[1], z = e.values[2];
                float delta = Math.abs(x - lastX) + Math.abs(y - lastY) + Math.abs(z - lastZ);
                lastX = x; lastY = y; lastZ = z;
                long now = SystemClock.uptimeMillis();
                if (delta > 9f && now - lastShake > 1500) {
                    lastShake = now;
                    for (PetView v : views) v.onShake();
                }
            }

            @Override
            public void onAccuracyChanged(Sensor s, int a) {
            }
        };
        sensorManager.registerListener(shakeListener, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
    }

    // -------- PetView.Host --------
    @Override
    public void requestMoveWindow(PetView v, int dx, int dy) {
        // 拖拽时立刻搬运窗口本身，宠物可停在屏幕任意位置
        WindowManager.LayoutParams lp = params.get(v);
        PetStore.Pet p = pets.get(v);
        if (lp == null || p == null) return;
        int nx = lp.x + dx;
        int ny = lp.y + dy;
        int minX = (int) (-lp.width * 0.35f);
        int maxX = (int) (sw - lp.width * 0.65f);
        int minY = (int) (-lp.height * 0.30f);
        int maxY = (int) (sh - lp.height * 0.70f);
        nx = Math.max(minX, Math.min(maxX, nx));
        ny = Math.max(minY, Math.min(maxY, ny));
        if (nx == lp.x && ny == lp.y) return;
        lp.x = nx;
        lp.y = ny;
        try {
            wm.updateViewLayout(v, lp);
        } catch (Exception e) {
            return;
        }
        p.relX = (nx + lp.width / 2f) / (float) sw;
        p.relY = (ny + lp.height / 2f) / (float) sh;
    }

    @Override
    public List<PetView> others(PetView self) {
        ArrayList<PetView> o = new ArrayList<PetView>();
        for (PetView v : views) if (v != self) o.add(v);
        return o;
    }

    @Override
    public void onPetChanged(PetView v) {
        PetStore.Pet p = pets.get(v);
        if (p == null) return;
        saveAll();
    }

    @Override
    public void buzz(int ms) {
        // 轻微触感反馈（无振动权限时系统自动忽略）
        try {
            android.os.Vibrator vib = (android.os.Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (vib != null) vib.vibrate(ms);
        } catch (Exception e) {
            // ignore
        }
    }

    @Override
    public void onDestroy() {
        running = false;
        handler.removeCallbacks(loop);
        saveAll();
        try {
            unregisterReceiver(screenReceiver);
        } catch (Exception e) {
            // ignore
        }
        if (sensorManager != null && shakeListener != null) {
            sensorManager.unregisterListener(shakeListener);
        }
        clearViews();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
