package com.deskpet.palx7k2m9;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    public static final int REQ_PICK_BG = 1001;
    private ImageView bg;
    private View scrim;
    private LinearLayout container;
    private Button btnToggle;
    private OutlineTextView notifInfo = null;
    private OutlineTextView cacheInfo = null;
    private List<File> junkFiles = new ArrayList<File>();

    private final BroadcastReceiver notifReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            refreshNotif();
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        bg = findViewById(R.id.bg);
        scrim = findViewById(R.id.scrim);
        container = findViewById(R.id.container);
        btnToggle = findViewById(R.id.btn_toggle);

        Button addT = findViewById(R.id.btn_add_template);
        Button addC = findViewById(R.id.btn_add_cutout);
        Button set = findViewById(R.id.btn_settings);

        btnToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleService();
            }
        });
        addT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTemplatePicker();
            }
        });
        addC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, CutoutActivity.class));
            }
        });
        set.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        GlassHelper.applyBackground(this, bg, scrim);
        buildUi();
        registerReceiver(notifReceiver, new IntentFilter(NotifEatService.ACTION_UPDATE));
        refreshNotif();
    }

    @Override
    protected void onPause() {
        try {
            unregisterReceiver(notifReceiver);
        } catch (Exception e) {
            // ignore
        }
        super.onPause();
    }

    private boolean overlayGranted() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) return Settings.canDrawOverlays(this);
        return true;
    }

    private void toggleService() {
        if (!overlayGranted()) {
            requestOverlay();
            return;
        }
        if (PetServiceHolder.isRunning) {
            Intent it = new Intent(this, PetService.class);
            it.setAction(PetService.ACTION_STOP);
            startService(it);
            PetServiceHolder.isRunning = false;
            btnToggle.setText("启动桌宠");
            Toast.makeText(this, "桌宠已休息", Toast.LENGTH_SHORT).show();
        } else {
            Intent it = new Intent(this, PetService.class);
            it.setAction(PetService.ACTION_REFRESH);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(it);
            else startService(it);
            PetServiceHolder.isRunning = true;
            btnToggle.setText("让桌宠休息");
            Toast.makeText(this, "桌宠出来啦！", Toast.LENGTH_SHORT).show();
        }
    }

    public static class PetServiceHolder {
        public static boolean isRunning = false;
    }

    // ---------------- UI ----------------
    private void buildUi() {
        container.removeAllViews();
        PetServiceHolder.isRunning = PetServiceHolder.isRunning && overlayGranted();
        btnToggle.setText(PetServiceHolder.isRunning ? "让桌宠休息" : "启动桌宠");

        // 1. 宠物列表
        LinearLayout c1 = GlassHelper.card(this, 14);
        c1.addView(GlassHelper.title(this, "我的宠物", 16));
        final List<PetStore.Pet> pets = PetStore.loadPets(this);
        if (pets.isEmpty()) {
            c1.addView(GlassHelper.label(this, "还没有宠物，点下面的按钮加一只吧～", 13));
        }
        for (int i = 0; i < pets.size(); i++) {
            c1.addView(petRow(pets.get(i)));
        }
        container.addView(c1);

        // 2. 照顾
        LinearLayout c2 = GlassHelper.card(this, 14);
        c2.addView(GlassHelper.title(this, "照顾它", 16));
        LinearLayout r2 = GlassHelper.row(this);
        Button feed = GlassHelper.wide(this, "喂食", false);
        Button clean = GlassHelper.wide(this, "清洁", false);
        Button play = GlassHelper.wide(this, "陪玩", false);
        feed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                care(0, "喂食");
            }
        });
        clean.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                care(1, "洗澡");
            }
        });
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                care(2, "陪玩");
            }
        });
        r2.addView(feed);
        r2.addView(clean);
        r2.addView(play);
        c2.addView(r2);
        container.addView(c2);

        // 3. 缓存吞噬
        LinearLayout c3 = GlassHelper.card(this, 14);
        c3.addView(GlassHelper.title(this, "缓存吞噬", 16));
        cacheInfo = GlassHelper.label(this, cacheDesc(), 12);
        c3.addView(cacheInfo);
        LinearLayout r3 = GlassHelper.row(this);
        Button scan = GlassHelper.wide(this, "扫描", false);
        Button eat = GlassHelper.wide(this, "开吃！", true);
        scan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doScan();
            }
        });
        eat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doEat();
            }
        });
        r3.addView(scan);
        r3.addView(eat);
        c3.addView(r3);
        container.addView(c3);

        // 4. 吞角标
        LinearLayout c4 = GlassHelper.card(this, 14);
        c4.addView(GlassHelper.title(this, "吞掉角标", 16));
        notifInfo = GlassHelper.label(this, "待吞噬通知：0 条", 13);
        c4.addView(notifInfo);
        LinearLayout r4 = GlassHelper.row(this);
        Button grant = GlassHelper.wide(this, "授权通知读取", false);
        Button eatNow = GlassHelper.wide(this, "现在吞一条", true);
        grant.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
                } catch (Exception e) {
                    // ignore
                }
            }
        });
        eatNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String what = NotifEatService.eatOne(MainActivity.this);
                if (what == null) {
                    Toast.makeText(MainActivity.this, "没有可吞的通知，或还没授权", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "吃掉：" + what, Toast.LENGTH_SHORT).show();
                    refreshNotif();
                }
            }
        });
        r4.addView(grant);
        r4.addView(eatNow);
        c4.addView(r4);
        c4.addView(GlassHelper.label(this, "开启后，宠物会把状态栏通知吃掉，桌面图标上的数字角标也会一起消失。", 11));
        container.addView(c4);

        // 5. 权限
        LinearLayout c5 = GlassHelper.card(this, 14);
        c5.addView(GlassHelper.title(this, "权限（都要开，功能才完整）", 16));
        c5.addView(permRow("悬浮窗（必须）", overlayGranted(), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestOverlay();
            }
        }));
        c5.addView(permRow("通知读取（吞角标）", NotifEatService.isEnabled(this), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
                } catch (Exception e) {
                    // ignore
                }
            }
        }));
        c5.addView(permRow("使用情况（缓存方案A）", usageGranted(), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
                } catch (Exception e) {
                    // ignore
                }
            }
        }));
        c5.addView(permRow("存储（抠图/清垃圾）", CacheEater.hasStoragePermission(this), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE}, 88);
                }
            }
        }));
        container.addView(c5);

        // 6. 说明
        LinearLayout c6 = GlassHelper.card(this, 14);
        c6.addView(GlassHelper.title(this, "玩法小贴士", 16));
        c6.addView(GlassHelper.label(this,
                "· 点它一下：蹭你、跳舞、装死，随机反应\n" +
                        "· 长按拖动：把它拎到别处，不挡你点App\n" +
                        "· 双击屏幕：吓它一跳\n" +
                        "· 摇一摇手机：它会晕，然后生闷气\n" +
                        "· 息屏自动睡觉，零耗电；亮屏它会假装刚玩完\n" +
                        "· 想养几只就养几只，它们会互相追逐", 12));
        container.addView(c6);
    }

    private View petRow(final PetStore.Pet p) {
        LinearLayout row = GlassHelper.row(this);
        row.setPadding(0, GlassHelper.dp(this, 8), 0, GlassHelper.dp(this, 8));

        ImageView iv = new ImageView(this);
        int s = GlassHelper.dp(this, 54);
        iv.setLayoutParams(new LinearLayout.LayoutParams(s, s));
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        if (p.kind == 1 && !p.frames.isEmpty()) {
            Bitmap b = GlassHelper.BitmapFactory2.decode(p.frames.get(0));
            if (b != null) iv.setImageBitmap(b);
            else iv.setImageBitmap(GlassHelper.previewOf(p.template, s));
        } else {
            iv.setImageBitmap(GlassHelper.previewOf(p.template, s));
        }

        LinearLayout txt = new LinearLayout(this);
        txt.setOrientation(LinearLayout.VERTICAL);
        txt.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        txt.setPadding(GlassHelper.dp(this, 10), 0, 0, 0);
        txt.addView(GlassHelper.label(this, p.name != null ? p.name : "小可爱", 14));
        txt.addView(GlassHelper.label(this, "心情 " + p.mood + " · 饱食 " + p.hunger + " · 清洁 " + p.clean, 11));

        Switch en = GlassHelper.sw(this, "", p.enabled);
        en.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton v, boolean checked) {
                List<PetStore.Pet> list = PetStore.loadPets(MainActivity.this);
                for (PetStore.Pet x : list) if (x.id != null && x.id.equals(p.id)) x.enabled = checked;
                PetStore.savePets(MainActivity.this, list);
                refreshService();
            }
        });

        Button del = new Button(this);
        del.setText("删");
        del.setTextColor(0xFFFFFFFF);
        del.setTextSize(12);
        del.setBackgroundResource(R.drawable.glass_button);
        del.setPadding(GlassHelper.dp(this, 10), 0, GlassHelper.dp(this, 10), 0);
        del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<PetStore.Pet> list = PetStore.loadPets(MainActivity.this);
                for (int i = 0; i < list.size(); i++) {
                    if (list.get(i).id != null && list.get(i).id.equals(p.id)) {
                        list.remove(i);
                        break;
                    }
                }
                PetStore.savePets(MainActivity.this, list);
                refreshService();
                buildUi();
            }
        });

        row.addView(iv);
        row.addView(txt);
        row.addView(en);
        row.addView(del);
        return row;
    }

    private View permRow(String name, boolean ok, View.OnClickListener l) {
        LinearLayout row = GlassHelper.row(this);
        row.setPadding(0, GlassHelper.dp(this, 5), 0, GlassHelper.dp(this, 5));
        OutlineTextView t = GlassHelper.label(this, (ok ? "✓ " : "· ") + name, 13);
        t.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        t.setGravity(Gravity.CENTER_VERTICAL);
        Button b = GlassHelper.button(this, ok ? "已开启" : "去开启", !ok);
        b.setOnClickListener(l);
        row.addView(t);
        row.addView(b);
        return row;
    }

    private void showTemplatePicker() {
        final String[] names = PetArt.NAMES;
        new AlertDialog.Builder(this)
                .setTitle("选一只内置宠物")
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        PetStore.Pet p = new PetStore.Pet();
                        p.id = "pet_" + System.currentTimeMillis();
                        p.name = names[which];
                        p.kind = 0;
                        p.template = which;
                        p.relX = 0.3f + (float) Math.random() * 0.4f;
                        p.relY = 0.6f + (float) Math.random() * 0.25f;
                        List<PetStore.Pet> list = PetStore.loadPets(MainActivity.this);
                        list.add(p);
                        PetStore.savePets(MainActivity.this, list);
                        refreshService();
                        buildUi();
                        Toast.makeText(MainActivity.this, names[which] + " 来啦！", Toast.LENGTH_SHORT).show();
                    }
                }).show();
    }

    private void care(int type, String tip) {
        List<PetStore.Pet> list = PetStore.loadPets(this);
        for (PetStore.Pet p : list) {
            if (type == 0) p.hunger = Math.min(100, p.hunger + 18);
            else if (type == 1) p.clean = Math.min(100, p.clean + 20);
            else p.mood = Math.min(100, p.mood + 16);
        }
        PetStore.savePets(this, list);
        Intent it = new Intent(this, PetService.class);
        it.setAction(PetService.ACTION_CARE);
        it.putExtra("type", type);
        it.putExtra("tip", tip);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(it);
            else startService(it);
        } catch (Exception e) {
            // ignore
        }
        buildUi();
        Toast.makeText(this, tip + " 完成！", Toast.LENGTH_SHORT).show();
    }

    private void refreshService() {
        if (!overlayGranted()) return;
        Intent it = new Intent(this, PetService.class);
        it.setAction(PetService.ACTION_REFRESH);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(it);
            else startService(it);
        } catch (Exception e) {
            // ignore
        }
        PetServiceHolder.isRunning = true;
    }

    private String cacheDesc() {
        PetStore.Settings s = PetStore.getSettings(this);
        switch (s.cacheMode) {
            case 0:
                return "方案A 真实统计：读取各应用使用情况，估算缓存占用，并一键跳到系统清理页。";
            case 1:
                return "方案B 清理公共垃圾：扫描下载目录等公共区域的临时文件，勾选后删除。";
            default:
                return "方案C 纯娱乐：不碰任何文件，只表演吃东西 + 涨饱食度。";
        }
    }

    private void doScan() {
        PetStore.Settings s = PetStore.getSettings(this);
        if (s.cacheMode == 0) {
            List<CacheEater.AppCache> list = CacheEater.scanByUsage(this);
            if (list.isEmpty()) {
                Toast.makeText(this, "没读到使用情况，请到上面的权限里开启「使用情况」", Toast.LENGTH_LONG).show();
                return;
            }
            StringBuilder sb = new StringBuilder("估算缓存排行：\n");
            long total = 0;
            for (int i = 0; i < Math.min(5, list.size()); i++) {
                CacheEater.AppCache a = list.get(i);
                total += a.estimateKb * 1024;
                sb.append(a.name).append("  ").append(CacheEater.human(a.estimateKb * 1024)).append("\n");
            }
            sb.append("合计 ≈ ").append(CacheEater.human(total)).append("（估算值）");
            showDialog("扫描结果", sb.toString(), list.get(0).pkg);
        } else if (s.cacheMode == 1) {
            if (!CacheEater.hasStoragePermission(this)) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE}, 88);
                }
                return;
            }
            junkFiles = CacheEater.scanJunk();
            long total = CacheEater.totalSize(junkFiles);
            showDialog("扫描结果", "找到 " + junkFiles.size() + " 个临时/垃圾文件，共 "
                    + CacheEater.human(total) + "\n点「开吃！」让宠物吃掉它们。", null);
        } else {
            showDialog("扫描结果", "方案C：纯娱乐模式，不扫描任何文件。点「开吃！」看它表演。", null);
        }
    }

    private void doEat() {
        PetStore.Settings s = PetStore.getSettings(this);
        if (s.cacheMode == 1 && !junkFiles.isEmpty()) {
            int n = CacheEater.deleteAll(junkFiles);
            junkFiles = new ArrayList<File>();
            Toast.makeText(this, "宠物吃掉了 " + n + " 个垃圾文件！", Toast.LENGTH_LONG).show();
            Intent it = new Intent(this, PetService.class);
            it.setAction(PetService.ACTION_CARE);
            it.putExtra("type", 0);
            it.putExtra("tip", "垃圾文件");
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(it);
                else startService(it);
            } catch (Exception e) {
                // ignore
            }
        } else if (s.cacheMode == 0) {
            List<CacheEater.AppCache> list = CacheEater.scanByUsage(this);
            if (!list.isEmpty()) {
                CacheEater.openSystemClean(this, list.get(0).pkg);
                Toast.makeText(this, "已打开系统清理页，点「清除缓存」即可", Toast.LENGTH_LONG).show();
            }
        } else {
            Intent it = new Intent(this, PetService.class);
            it.setAction(PetService.ACTION_CARE);
            it.putExtra("type", 0);
            it.putExtra("tip", "空气");
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(it);
                else startService(it);
            } catch (Exception e) {
                // ignore
            }
            Toast.makeText(this, "它假装吃得很开心～", Toast.LENGTH_SHORT).show();
        }
    }

    private void showDialog(String title, String msg, final String pkg) {
        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(msg)
                .setPositiveButton("知道了", null);
        if (pkg != null) {
            b.setNeutralButton("去系统清理", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface d, int w) {
                    CacheEater.openSystemClean(MainActivity.this, pkg);
                }
            });
        }
        b.show();
    }

    private void refreshNotif() {
        if (notifInfo != null) {
            int n = NotifEatService.pendingCount();
            boolean on = NotifEatService.isEnabled(this);
            notifInfo.setText(on ? ("待吞噬通知：" + n + " 条") : "还没授权通知读取，点下面按钮去开启");
        }
    }

    private boolean usageGranted() {
        try {
            android.app.AppOpsManager aom = (android.app.AppOpsManager) getSystemService(APP_OPS_SERVICE);
            int mode = aom.checkOpNoThrow("android:get_usage_stats", android.os.Process.myUid(), getPackageName());
            return mode == android.app.AppOpsManager.MODE_ALLOWED;
        } catch (Exception e) {
            return false;
        }
    }

    private void requestOverlay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                Intent it = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(it);
            } catch (Exception e) {
                // ignore
            }
        }
    }

    /** 供设置页保存背景图使用 */
    public static String copyBg(Activity a, Uri uri) {
        try {
            File f = new File(a.getFilesDir(), "bg.png");
            java.io.InputStream in = a.getContentResolver().openInputStream(uri);
            FileOutputStream out = new FileOutputStream(f);
            byte[] buf = new byte[8192];
            int len;
            while ((len = in.read(buf)) > 0) out.write(buf, 0, len);
            in.close();
            out.close();
            return f.getAbsolutePath();
        } catch (Exception e) {
            return null;
        }
    }
}
