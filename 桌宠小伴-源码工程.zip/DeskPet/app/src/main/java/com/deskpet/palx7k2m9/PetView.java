package com.deskpet.palx7k2m9;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.SystemClock;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/**
 * 单只桌宠的视图：负责状态机、动画、绘制、触摸交互。
 * 内置模板用 Canvas 手绘（天然会动）；图片宠物用帧动画 + 部件摆动。
 */
public class PetView extends View {

    public interface Host {
        void requestMoveWindow(PetView v, int dx, int dy);
        List<PetView> others(PetView self);
        void onPetChanged(PetView v);
        void buzz(int ms);
    }

    private Host host;
    private PetStore.Pet pet;
    private int winW, winH;              // 窗口尺寸
    private float px, py;                // 宠物在窗口内的位置（中心）
    private float vx = 0, vy = 0;        // 速度 px/s
    private int state = PetArt.ST_IDLE;
    private float stateTime = 0;         // 当前状态持续秒数
    private float lifeTime = 0;          // 总动画时间
    private int dir = 1;                 // 朝向
    private int faceDir = 1;             // 视觉朝向
    private float targetX = -1;          // 行走目标
    private String bubble = null;
    private float bubbleTime = 0;
    private long lastMs = 0;

    // 图片宠物
    private ArrayList<Bitmap> frames = new ArrayList<Bitmap>();
    private Bitmap headBmp = null, bodyBmp = null;
    private int frameIdx = 0;
    private float frameAcc = 0;

    private Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Matrix mtx = new Matrix();
    private float scaleX = 1f, scaleY = 1f;   // 挤压拉伸
    private float rot = 0f;                    // 旋转（打滚）
    private float jumpOffset = 0f;
    private float angryShake = 0f;
    private boolean dragging = false;
    private float dragStartX, dragStartY;
    private boolean movedFlag = false;

    private GestureDetector gesture;
    private boolean sleeping = false;
    private float moodAnim = 0;

    public PetView(Context c, Host h, PetStore.Pet p, int winW, int winH) {
        super(c);
        this.host = h;
        this.pet = p;
        this.winW = winW;
        this.winH = winH;
        this.px = winW / 2f;
        this.py = winH / 2f;
        loadFrames();
        gesture = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onDoubleTap(MotionEvent e) {
                if (SettingsActivity.isOn(getContext(), "doubleTap", true)) {
                    setState(PetArt.ST_STARTLED);
                    showBubble("吓我一跳！");
                    return true;
                }
                return false;
            }

            @Override
            public void onLongPress(MotionEvent e) {
                dragging = true;
                setState(PetArt.ST_DRAG);
                showBubble("拎我干嘛~");
            }

            @Override
            public boolean onSingleTapConfirmed(MotionEvent e) {
                if (movedFlag) return true;
                reactToTap();
                return true;
            }
        });
        lastMs = SystemClock.uptimeMillis();
        randomStateSoon();
    }

    public PetStore.Pet getPet() {
        return pet;
    }

    private void loadFrames() {
        frames.clear();
        if (pet.kind == 1) {
            for (String path : pet.frames) {
                if (path == null || path.length() == 0) continue;
                Bitmap b = BitmapFactory.decodeFile(path);
                if (b != null) frames.add(b);
            }
            buildParts();
        }
    }

    private void buildParts() {
        if (frames.isEmpty()) return;
        Bitmap src = frames.get(0);
        int h = src.getHeight();
        int cut = (int) (h * 0.48f);
        if (cut < 1 || cut >= h) return;
        try {
            headBmp = Bitmap.createBitmap(src, 0, 0, src.getWidth(), cut);
            bodyBmp = Bitmap.createBitmap(src, 0, cut, src.getWidth(), h - cut);
        } catch (Exception e) {
            headBmp = null;
            bodyBmp = null;
        }
    }

    public void reload() {
        loadFrames();
        invalidate();
    }

    public void setWindowSize(int w, int h) {
        winW = w;
        winH = h;
    }

    // ---------------- 外部指令 ----------------
    public void reactToTap() {
        int r = (int) (Math.random() * 4);
        switch (r) {
            case 0:
                setState(PetArt.ST_PLAY);
                showBubble("好开心！蹭蹭~");
                pet.mood = clamp(pet.mood + 4);
                break;
            case 1:
                setState(PetArt.ST_ANGRY);
                showBubble("别烦我！");
                pet.mood = clamp(pet.mood - 2);
                break;
            case 2:
                setState(PetArt.ST_ROLL);
                showBubble("装死中…");
                break;
            default:
                setState(PetArt.ST_DANCE);
                showBubble("跳舞给你看！");
                pet.mood = clamp(pet.mood + 3);
                break;
        }
        if (host != null) host.buzz(18);
        changed();
    }

    public void onShake() {
        setState(PetArt.ST_ANGRY);
        angryShake = 1f;
        showBubble("摇得我头晕！");
        pet.mood = clamp(pet.mood - 3);
        changed();
    }

    public void eat(String what) {
        setState(PetArt.ST_EAT);
        showBubble("吃掉" + what + "！");
        pet.hunger = clamp(pet.hunger + 8);
        pet.mood = clamp(pet.mood + 3);
        changed();
    }

    public void fakeWake(String msg) {
        setState(PetArt.ST_PLAY);
        showBubble(msg);
    }

    public void goSleep(boolean on) {
        sleeping = on;
        if (on) setState(PetArt.ST_SLEEP);
        else setState(PetArt.ST_IDLE);
    }

    public int getState() {
        return state;
    }

    public void setState(int st) {
        state = st;
        stateTime = 0;
        if (st == PetArt.ST_JUMP) jumpOffset = 0;
        if (st == PetArt.ST_ROLL) rot = 0;
        if (st != PetArt.ST_SLEEP) sleeping = false;
    }

    public void showBubble(String text) {
        bubble = text;
        bubbleTime = 0;
    }

    private int clamp(int v) {
        return Math.max(0, Math.min(100, v));
    }

    // ---------------- 逻辑更新 ----------------
    public void update(long nowMs) {
        if (lastMs == 0) lastMs = nowMs;
        long d = nowMs - lastMs;
        if (d <= 0) return;
        if (d > 200) d = 200;   // 息屏回来不做大跳变
        lastMs = nowMs;
        float dt = d / 1000f;
        lifeTime += dt;
        stateTime += dt;
        bubbleTime += dt;

        if (bubble != null && bubbleTime > 3.2f) bubble = null;

        float sp = 60f * (pet.speed / 100f) * (PetStore.getSettings(getContext()).walkSpeed / 100f);

        switch (state) {
            case PetArt.ST_WALK:
                walkLogic(dt, sp);
                break;
            case PetArt.ST_JUMP: {
                float dur = 0.75f;
                float t = stateTime / dur;
                jumpOffset = -(float) Math.sin(Math.PI * Math.min(t, 1f)) * winH * 0.22f;
                px += vx * dt;
                if (stateTime > dur) {
                    jumpOffset = 0;
                    setState(PetArt.ST_IDLE);
                }
                break;
            }
            case PetArt.ST_ROLL: {
                rot += dt * 720f;
                px += dir * sp * 1.3f * dt;
                if (stateTime > 1.1f) {
                    rot = 0;
                    setState(PetArt.ST_IDLE);
                }
                break;
            }
            case PetArt.ST_SLEEP:
                vx = 0;
                break;
            case PetArt.ST_STARTLED: {
                float t = stateTime / 0.5f;
                jumpOffset = -(float) Math.sin(Math.PI * Math.min(t, 1f)) * winH * 0.16f;
                if (stateTime > 0.6f) {
                    jumpOffset = 0;
                    setState(PetArt.ST_IDLE);
                }
                break;
            }
            case PetArt.ST_ANGRY:
                angryShake = Math.max(0, 1f - stateTime / 0.8f);
                if (stateTime > 1.4f) setState(PetArt.ST_IDLE);
                break;
            case PetArt.ST_PLAY:
            case PetArt.ST_DANCE:
                vx = 0;
                if (stateTime > 2.2f) setState(PetArt.ST_IDLE);
                break;
            case PetArt.ST_EAT:
                vx = 0;
                if (stateTime > 1.6f) setState(PetArt.ST_IDLE);
                break;
            case PetArt.ST_DRAG:
                vx = 0;
                break;
            default: // IDLE
                vx *= 0.9f;
                if (stateTime > 1.2f + Math.random() * 2.5f) randomStateSoon();
                break;
        }

        // 心情很低：背对 + 不理人
        boolean lowMood = pet.mood < 25;
        moodAnim += ((lowMood ? 1f : 0f) - moodAnim) * dt * 3f;

        // 边界与窗口跟随
        float margin = winW * 0.30f;
        if (px < margin) { px = margin; vx = Math.abs(vx); dir = 1; }
        if (px > winW - margin) { px = winW - margin; vx = -Math.abs(vx); dir = -1; }
        if (py < margin) py = margin;
        if (py > winH - margin) py = winH - margin;

        faceDir = dir;

        // 帧动画
        if (pet.kind == 1 && frames.size() > 1) {
            frameAcc += dt;
            float per = 1f / Math.max(1, pet.fps);
            if (frameAcc >= per) {
                frameAcc = 0;
                frameIdx = (frameIdx + 1) % frames.size();
            }
        }

        invalidate();
    }

    private void walkLogic(float dt, float sp) {
        if (targetX < 0) {
            targetX = winW * (0.2f + (float) Math.random() * 0.6f);
            dir = targetX > px ? 1 : -1;
        }
        float dx = targetX - px;
        if (Math.abs(dx) < 6) {
            targetX = -1;
            setState((Math.random() < 0.25f) ? PetArt.ST_IDLE : PetArt.ST_WALK);
            if (state == PetArt.ST_IDLE) stateTime = 0;
            return;
        }
        vx = dir * sp;
        px += vx * dt;
        if (stateTime > 6f) {
            targetX = -1;
            setState(PetArt.ST_IDLE);
        }
    }

    /** 同伴追逐：偶尔把目标设成另一只宠物 */
    public void chase(PetView other) {
        if (state == PetArt.ST_SLEEP || dragging) return;
        float ox = other.px;
        dir = ox > px ? 1 : -1;
        if (Math.abs(ox - px) > winW * 0.5f) {
            vx = dir * 90f * (pet.speed / 100f);
        }
    }

    private void randomStateSoon() {
        double r = Math.random();
        if (pet.hunger < 25 && r < 0.3) {
            showBubble("肚子饿了…");
            setState(PetArt.ST_IDLE);
        } else if (r < 0.45) {
            setState(PetArt.ST_WALK);
            targetX = -1;
        } else if (r < 0.58) {
            setState(PetArt.ST_JUMP);
        } else if (r < 0.68) {
            setState(PetArt.ST_ROLL);
        } else if (r < 0.78 && pet.mood > 70) {
            setState(PetArt.ST_DANCE);
        } else if (r < 0.86) {
            setState(PetArt.ST_SLEEP);
        } else {
            setState(PetArt.ST_IDLE);
        }
    }

    private void changed() {
        if (host != null) host.onPetChanged(this);
    }

    // ---------------- 触摸 ----------------
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        gesture.onTouchEvent(event);
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                dragStartX = event.getRawX();
                dragStartY = event.getRawY();
                movedFlag = false;
                return true;
            case MotionEvent.ACTION_MOVE:
                if (dragging) {
                    float dx = event.getRawX() - dragStartX;
                    float dy = event.getRawY() - dragStartY;
                    if (Math.abs(dx) > 2 || Math.abs(dy) > 2) {
                        movedFlag = true;
                        px += dx;
                        py += dy;
                        dragStartX = event.getRawX();
                        dragStartY = event.getRawY();
                        clampInWindow();
                        invalidate();
                    }
                    return true;
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (dragging) {
                    dragging = false;
                    setState(PetArt.ST_IDLE);
                    pet.relX = clampF(currentRelX());
                    pet.relY = clampF(currentRelY());
                    changed();
                    return true;
                }
                break;
        }
        return true;
    }

    private void clampInWindow() {
        float margin = winW * 0.25f;
        px = Math.max(margin, Math.min(winW - margin, px));
        py = Math.max(margin, Math.min(winH - margin, py));
    }

    private float clampF(float v) {
        return Math.max(0.02f, Math.min(0.98f, v));
    }

    /** 宠物相对屏幕的绝对位置（由 Service 计算窗口偏移 + 内部偏移） */
    public float currentRelX() {
        return pet.relX;
    }

    public float currentRelY() {
        return pet.relY;
    }

    // ---------------- 绘制 ----------------
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float size = winW * 0.44f;
        float cx = px;
        float cy = py + jumpOffset;

        canvas.save();
        if (angryShake > 0) {
            canvas.translate((float) (Math.sin(lifeTime * 60) * 4 * angryShake), 0);
        }
        canvas.translate(cx, cy);
        canvas.rotate(rot);
        if (state == PetArt.ST_SLEEP) canvas.rotate(72f);
        if (state == PetArt.ST_DANCE) canvas.rotate((float) Math.sin(lifeTime * 9) * 12f);
        if (state == PetArt.ST_PLAY) canvas.scale(1.06f, 0.94f);

        // 影子
        if (state != PetArt.ST_SLEEP) {
            Paint sh = new Paint(Paint.ANTI_ALIAS_FLAG);
            sh.setColor(0x22000000);
            sh.setStyle(Paint.Style.FILL);
            float sw = size * 0.5f * (1f - Math.abs(jumpOffset) / (winH * 0.3f));
            canvas.drawOval(new RectF(-sw, size * 0.42f, sw, size * 0.52f), sh);
        }

        float half = size * 0.5f;
        if (pet.kind == 1 && !frames.isEmpty()) {
            drawBitmapPet(canvas, half);
        } else {
            canvas.save();
            canvas.translate(-half, -size * 0.5f);
            if (faceDir < 0) {
                canvas.scale(-1f, 1f, half, 0);
            }
            if (moodAnim > 0.02f) {
                canvas.translate(half, 0);
                canvas.scale(-1, 1);
                canvas.translate(-half, 0);
            }
            PetArt.draw(canvas, pet.template, size, size, state, lifeTime, pet.mood, faceDir);
            canvas.restore();
        }

        // 心情低：半透明灰
        if (moodAnim > 0.02f) {
            // 已通过背对表现，这里不再叠加滤镜，避免图片宠物失真
        }
        canvas.restore();

        if (state == PetArt.ST_SLEEP) drawZzz(canvas, cx, cy - size * 0.6f);
        if (bubble != null && PetStore.getSettings(getContext()).showBubble) {
            drawBubble(canvas, cx, cy - size * 0.62f, bubble);
        }
    }

    private void drawBitmapPet(Canvas canvas, float half) {
        Bitmap b = frames.get(Math.min(frameIdx, frames.size() - 1));
        float scale = (half * 2f) / Math.max(b.getWidth(), b.getHeight());
        float dw = b.getWidth() * scale, dh = b.getHeight() * scale;
        canvas.save();
        if (faceDir < 0) canvas.scale(-1f, 1f);
        if (moodAnim > 0.02f) canvas.scale(-1f, 1f);
        if (pet.partAnim && headBmp != null && bodyBmp != null && frames.size() == 1) {
            float bs = (half * 2f) / Math.max(bodyBmp.getWidth(), bodyBmp.getHeight() + headBmp.getHeight());
            float bw = bodyBmp.getWidth() * bs, bh = bodyBmp.getHeight() * bs;
            float hw = headBmp.getWidth() * bs, hh = headBmp.getHeight() * bs;
            float totalH = bh + hh;
            float top = -totalH / 2f;
            canvas.drawBitmap(bodyBmp, null, new RectF(-bw / 2f, top + hh, bw / 2f, top + hh + bh), paint);
            float deg = (float) Math.sin(lifeTime * (state == PetArt.ST_WALK ? 7f : 2.2f)) * 6f;
            canvas.save();
            canvas.rotate(deg, 0, top + hh);
            float bobY = (float) Math.abs(Math.sin(lifeTime * (state == PetArt.ST_WALK ? 7f : 2.2f))) * -2f;
            canvas.drawBitmap(headBmp, null, new RectF(-hw / 2f, top + bobY, hw / 2f, top + hh + bobY), paint);
            canvas.restore();
        } else {
            canvas.drawBitmap(b, null, new RectF(-dw / 2f, -dh / 2f, dw / 2f, dh / 2f), paint);
        }
        canvas.restore();
    }

    private void drawZzz(Canvas c, float x, float y) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setTextSize(Math.max(18f, winW * 0.06f));
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(2f, winW * 0.012f));
        p.setColor(0xCC000000);
        c.drawText("Z z z", x, y, p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFFFFFFF);
        c.drawText("Z z z", x, y, p);
    }

    /** 玻璃气泡：白字 + 黑描边，任何背景都看得清 */
    private void drawBubble(Canvas c, float x, float y, String text) {
        Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
        tp.setTextSize(Math.max(20f, winW * 0.075f));
        float tw = tp.measureText(text);
        float padX = 16f, padY = 12f;
        float bw = tw + padX * 2, bh = tp.getTextSize() + padY * 2;
        float left = x - bw / 2, top = y - bh;

        Paint glass = new Paint(Paint.ANTI_ALIAS_FLAG);
        glass.setColor(0x55222230);
        RectF r = new RectF(left, top, left + bw, top + bh);
        c.drawRoundRect(r, bh * 0.42f, bh * 0.42f, glass);

        Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
        edge.setStyle(Paint.Style.STROKE);
        edge.setStrokeWidth(2f);
        edge.setColor(0x66FFFFFF);
        c.drawRoundRect(r, bh * 0.42f, bh * 0.42f, edge);

        tp.setTextAlign(Paint.Align.CENTER);
        tp.setStyle(Paint.Style.STROKE);
        tp.setStrokeWidth(3.5f);
        tp.setColor(0xDD000000);
        c.drawText(text, x, top + bh - padY * 1.1f, tp);
        tp.setStyle(Paint.Style.FILL);
        tp.setColor(0xFFFFFFFF);
        c.drawText(text, x, top + bh - padY * 1.1f, tp);
    }

    public float getPx() {
        return px;
    }

    public float getPy() {
        return py;
    }

    public void setP(float x, float y) {
        px = x;
        py = y;
    }
}
