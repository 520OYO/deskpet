package com.deskpet.palx7k2m9;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class SettingsActivity extends Activity {

    public static final int REQ_BG = 2001;
    private LinearLayout container;
    private ImageView bg;
    private View scrim;
    private OutlineTextView cacheDesc;

    public static boolean isOn(Context c, String key, boolean def) {
        try {
            PetStore.Settings s = PetStore.getSettings(c);
            if ("doubleTap".equals(key)) return s.doubleTap;
            if ("shakeEnabled".equals(key)) return s.shakeEnabled;
            if ("followFinger".equals(key)) return s.followFinger;
            if ("showBubble".equals(key)) return s.showBubble;
        } catch (Exception e) {
            // ignore
        }
        return def;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_settings);
        bg = findViewById(R.id.bg);
        scrim = findViewById(R.id.scrim);
        container = findViewById(R.id.container);
        Button back = findViewById(R.id.btn_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        build();
    }

    @Override
    protected void onResume() {
        super.onResume();
        GlassHelper.applyBackground(this, bg, scrim);
    }

    private PetStore.Settings s() {
        return PetStore.getSettings(this);
    }

    private void save(PetStore.Settings s) {
        PetStore.saveSettings(this, s);
    }

    private void build() {
        container.removeAllViews();
        final PetStore.Settings s = s();

        // 外观
        LinearLayout c1 = GlassHelper.card(this, 14);
        c1.addView(GlassHelper.title(this, "外观：液态玻璃", 16));
        LinearLayout rBg = GlassHelper.row(this);
        Button pick = GlassHelper.wide(this, "换背景图", true);
        Button clearBg = GlassHelper.wide(this, "用默认背景", false);
        pick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                it.addCategory(Intent.CATEGORY_OPENABLE);
                it.setType("image/*");
                try {
                    startActivityForResult(it, REQ_BG);
                } catch (Exception e) {
                    // ignore
                }
            }
        });
        clearBg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PetStore.Settings st = s();
                st.bgPath = "";
                save(st);
                bg.setImageDrawable(null);
                Toast.makeText(SettingsActivity.this, "已恢复默认背景", Toast.LENGTH_SHORT).show();
            }
        });
        rBg.addView(pick);
        rBg.addView(clearBg);
        c1.addView(rBg);
        c1.addView(seek("玻璃透明度（越小越透）", s.glassAlpha, 10, 90, new OnVal() {
            public void on(int v) {
                PetStore.Settings st = s();
                st.glassAlpha = v;
                save(st);
                build();
            }
        }));
        c1.addView(seek("背景压暗（保证白字清楚）", s.scrimAlpha, 0, 45, new OnVal() {
            public void on(int v) {
                PetStore.Settings st = s();
                st.scrimAlpha = v;
                save(st);
                GlassHelper.applyBackground(SettingsActivity.this, bg, scrim);
            }
        }));
        c1.addView(seek("白字描边粗细", (int) (s.strokeWidth * 10), 0, 60, new OnVal() {
            public void on(int v) {
                PetStore.Settings st = s();
                st.strokeWidth = v / 10f;
                save(st);
                build();
            }
        }));
        container.addView(c1);

        // 宠物
        LinearLayout c2 = GlassHelper.card(this, 14);
        c2.addView(GlassHelper.title(this, "宠物", 16));
        c2.addView(seek("默认体型", defaultSize(), 48, 170, new OnVal() {
            public void on(int v) {
                setAllSize(v);
            }
        }));
        c2.addView(seek("移动速度", s.walkSpeed, 30, 220, new OnVal() {
            public void on(int v) {
                PetStore.Settings st = s();
                st.walkSpeed = v;
                save(st);
            }
        }));
        c2.addView(GlassHelper.label(this, "想养几只？回主界面点「加内置宠物」或「抠图做宠物」，一只到十几只都行，它们会互相追逐。", 12));
        container.addView(c2);

        // 缓存方案
        LinearLayout c3 = GlassHelper.card(this, 14);
        c3.addView(GlassHelper.title(this, "缓存吞噬方案", 16));
        RadioGroup rg = new RadioGroup(this);
        rg.setOrientation(RadioGroup.VERTICAL);
        final String[] opts = {"方案A：真实统计（读使用情况 + 跳系统清理页）",
                "方案B：清理公共垃圾（删临时文件）",
                "方案C：纯娱乐（不碰任何文件）"};
        for (int i = 0; i < opts.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setText(opts[i]);
            rb.setTextColor(0xFFFFFFFF);
            rb.setTextSize(13);
            rb.setId(1000 + i);
            rg.addView(rb);
        }
        rg.check(1000 + s.cacheMode);
        cacheDesc = GlassHelper.label(this, cacheText(s.cacheMode), 12);
        c3.addView(rg);
        c3.addView(cacheDesc);
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int id) {
                PetStore.Settings st = s();
                st.cacheMode = id - 1000;
                save(st);
                cacheDesc.setText(cacheText(st.cacheMode));
            }
        });
        container.addView(c3);

        // 交互
        LinearLayout c4 = GlassHelper.card(this, 14);
        c4.addView(GlassHelper.title(this, "交互与省电", 16));
        c4.addView(switchRow("吞掉通知角标", s.eatBadge, new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton v, boolean c) {
                PetStore.Settings st = s();
                st.eatBadge = c;
                save(st);
            }
        }));
        c4.addView(switchRow("息屏就睡觉（最省电）", s.sleepOnScreenOff, new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton v, boolean c) {
                PetStore.Settings st = s();
                st.sleepOnScreenOff = c;
                save(st);
            }
        }));
        c4.addView(switchRow("摇一摇有反应", s.shakeEnabled, new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton v, boolean c) {
                PetStore.Settings st = s();
                st.shakeEnabled = c;
                save(st);
            }
        }));
        c4.addView(switchRow("双击吓它一跳", s.doubleTap, new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton v, boolean c) {
                PetStore.Settings st = s();
                st.doubleTap = c;
                save(st);
            }
        }));
        c4.addView(switchRow("显示气泡对话", s.showBubble, new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton v, boolean c) {
                PetStore.Settings st = s();
                st.showBubble = c;
                save(st);
            }
        }));
        c4.addView(switchRow("开机自动出来", s.bootStart, new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton v, boolean c) {
                PetStore.Settings st = s();
                st.bootStart = c;
                save(st);
            }
        }));
        container.addView(c4);

        // 数据
        LinearLayout c5 = GlassHelper.card(this, 14);
        c5.addView(GlassHelper.title(this, "数据", 16));
        Button clear = GlassHelper.wide(this, "清空所有宠物", false);
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PetStore.savePets(SettingsActivity.this, new ArrayList<PetStore.Pet>());
                Toast.makeText(SettingsActivity.this, "已清空", Toast.LENGTH_SHORT).show();
            }
        });
        c5.addView(clear);
        c5.addView(GlassHelper.label(this, "所有数据都只存在你手机里，不会上传，也没有任何付费内容。", 12));
        container.addView(c5);
    }

    private String cacheText(int mode) {
        switch (mode) {
            case 0:
                return "说明：安卓不允许第三方直接删除别的应用缓存，所以 A 方案读取使用情况做估算，并一键跳到系统清理页，你在系统页点一下就真正清掉了。";
            case 1:
                return "说明：B 方案扫描下载目录等公共区域的临时文件（.tmp/.log/.bak 等）和 0 字节空文件，宠物吃掉 = 真的删除。";
            default:
                return "说明：C 方案完全不碰你的文件，只是表演吃东西 + 涨饱食度，纯图个乐。";
        }
    }

    private int defaultSize() {
        List<PetStore.Pet> list = PetStore.loadPets(this);
        if (list.isEmpty()) return 88;
        return list.get(0).sizeDp;
    }

    private void setAllSize(int dp) {
        List<PetStore.Pet> list = PetStore.loadPets(this);
        for (PetStore.Pet p : list) p.sizeDp = dp;
        PetStore.savePets(this, list);
        Intent it = new Intent(this, PetService.class);
        it.setAction(PetService.ACTION_REFRESH);
        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) startForegroundService(it);
            else startService(it);
        } catch (Exception e) {
            // ignore
        }
    }

    private View switchRow(String text, boolean checked, CompoundButton.OnCheckedChangeListener l) {
        LinearLayout row = GlassHelper.row(this);
        row.setPadding(0, GlassHelper.dp(this, 4), 0, GlassHelper.dp(this, 4));
        Switch sw = GlassHelper.sw(this, text, checked);
        sw.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        sw.setOnCheckedChangeListener(l);
        row.addView(sw);
        return row;
    }

    public interface OnVal {
        void on(int v);
    }

    private View seek(String title, int value, int min, int max, final OnVal cb) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        OutlineTextView t = GlassHelper.label(this, title + "：" + value, 13);
        box.addView(t);
        SeekBar sb = new SeekBar(this);
        sb.setMax(max - min);
        sb.setProgress(value - min);
        final int[] cur = {value};
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                cur[0] = p + min;
                t.setText(title + "：" + cur[0]);
            }

            public void onStartTrackingTouch(SeekBar s) {
            }

            public void onStopTrackingTouch(SeekBar s) {
                cb.on(cur[0]);
            }
        });
        box.addView(sb);
        return box;
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_BG && res == RESULT_OK && data != null && data.getData() != null) {
            String p = MainActivity.copyBg(this, data.getData());
            if (p != null) {
                PetStore.Settings st = s();
                st.bgPath = p;
                save(st);
                GlassHelper.applyBackground(this, bg, scrim);
                Toast.makeText(this, "背景已更换", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
