package com.deskpet.palx7k2m9;

import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * 缓存吞噬的三种方案（设置里自由切换）：
 * A 真实统计：读取各应用使用情况，估算缓存占用，并一键跳转到系统清理页（安卓不允许第三方直接清别人的缓存）
 * B 清理公共垃圾：扫描下载目录等公共区域的临时文件，勾选后删除
 * C 纯娱乐：不碰任何文件，只是表演吃东西 + 涨饱食度
 */
public class CacheEater {

    public static class AppCache {
        public String pkg;
        public String name;
        public long minutes;      // 近 7 天使用分钟
        public long estimateKb;   // 估算缓存(KB)
    }

    // ---------- 方案 A ----------
    public static List<AppCache> scanByUsage(Context c) {
        List<AppCache> out = new ArrayList<AppCache>();
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return out;
        UsageStatsManager usm = (UsageStatsManager) c.getSystemService(Context.USAGE_STATS_SERVICE);
        if (usm == null) return out;
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, -7);
        List<UsageStats> stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_BEST,
                cal.getTimeInMillis(), System.currentTimeMillis());
        if (stats == null || stats.isEmpty()) return out;
        for (UsageStats s : stats) {
            long ms = 0;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && s.getTotalTimeInForeground() >= 0) {
                ms = s.getTotalTimeInForeground();
            } else {
                try {
                    ms = s.getTotalTimeInForeground();
                } catch (Exception e) {
                    ms = 0;
                }
            }
            long min = ms / 60000;
            if (min <= 0) continue;
            AppCache a = new AppCache();
            a.pkg = s.getPackageName();
            a.name = NotifEatService.appLabel(c, a.pkg);
            a.minutes = min;
            a.estimateKb = min * 900L;   // 估算：每分钟约 0.9MB 缓存堆积
            out.add(a);
        }
        Collections.sort(out, new Comparator<AppCache>() {
            @Override
            public int compare(AppCache a, AppCache b) {
                return Long.compare(b.estimateKb, a.estimateKb);
            }
        });
        if (out.size() > 30) return out.subList(0, 30);
        return out;
    }

    /** 跳转到系统自带的存储清理页（唯一真正能清他人缓存的入口） */
    public static void openSystemClean(Context c, String pkg) {
        try {
            Intent it;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                it = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            } else {
                it = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            }
            it.setData(Uri.parse("package:" + pkg));
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(it);
        } catch (Exception e) {
            try {
                Intent it = new Intent(android.provider.Settings.ACTION_INTERNAL_STORAGE_SETTINGS);
                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                c.startActivity(it);
            } catch (Exception e2) {
                // ignore
            }
        }
    }

    // ---------- 方案 B ----------
    private static final String[] JUNK_EXT = {".tmp", ".temp", ".log", ".crdownload", ".part",
            ".download", ".bak", ".old", ".cache", ".dmp", ".thumb", ".mta", ".st"};

    public static List<File> scanJunk() {
        List<File> out = new ArrayList<File>();
        File root = Environment.getExternalStorageDirectory();
        String[] dirs = {"Download", "Downloads", "DCIM/.thumbnails", "Pictures", "Movies", "Bluetooth"};
        for (String d : dirs) {
            File dir = new File(root, d);
            collectJunk(dir, out, 0);
        }
        collectJunk(new File(root, "Android/data"), out, 0);
        return out;
    }

    private static void collectJunk(File dir, List<File> out, int depth) {
        if (dir == null || !dir.exists() || !dir.isDirectory() || depth > 3) return;
        File[] fs = dir.listFiles();
        if (fs == null) return;
        for (File f : fs) {
            if (f.isDirectory()) {
                collectJunk(f, out, depth + 1);
            } else {
                String n = f.getName().toLowerCase();
                boolean junk = false;
                for (String e : JUNK_EXT) if (n.endsWith(e)) junk = true;
                if (!junk && f.length() == 0) junk = true;     // 0 字节空文件
                if (junk && out.size() < 3000) out.add(f);
            }
        }
    }

    public static long totalSize(List<File> list) {
        long t = 0;
        for (File f : list) t += f.length();
        return t;
    }

    public static int deleteAll(List<File> list) {
        int n = 0;
        for (File f : list) {
            try {
                if (f != null && f.exists() && f.delete()) n++;
            } catch (Exception e) {
                // ignore
            }
        }
        return n;
    }

    // ---------- 通用 ----------
    public static String human(long bytes) {
        if (bytes < 1024) return bytes + "B";
        if (bytes < 1024 * 1024) return String.format("%.1fKB", bytes / 1024f);
        if (bytes < 1024 * 1024 * 1024) return String.format("%.1fMB", bytes / 1024f / 1024f);
        return String.format("%.2fGB", bytes / 1024f / 1024f / 1024f);
    }

    public static boolean hasStoragePermission(Context c) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true;
        return c.checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED;
    }
}
