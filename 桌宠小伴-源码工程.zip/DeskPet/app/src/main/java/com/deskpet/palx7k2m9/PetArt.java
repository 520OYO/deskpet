package com.deskpet.palx7k2m9;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;

/**
 * 内置模板宠物：纯 Canvas 手绘的 2D 卡通形象，线条干净、颜色鲜明。
 * 因为是画出来的，所以天然"会动"：呼吸、眨眼、走路摆腿、尾巴摆动、情绪表情全都有。
 */
public class PetArt {

    public static final String[] NAMES = {"小白猫", "柴柴", "小怪物", "小幽灵"};
    public static final int COUNT = 4;

    // 状态常量（与 PetView 保持一致）
    public static final int ST_IDLE = 0, ST_WALK = 1, ST_JUMP = 2, ST_ROLL = 3,
            ST_SLEEP = 4, ST_EAT = 5, ST_DANCE = 6, ST_ANGRY = 7, ST_STARTLED = 8,
            ST_DRAG = 9, ST_PLAY = 10;

    public static String nameOf(int t) {
        return NAMES[t >= 0 && t < COUNT ? t : 0];
    }

    /**
     * @param w,h  绘制区域（脚底在 y=h）
     * @param st   状态
     * @param time 动画时间（秒）
     * @param mood 心情 0-100
     * @param dir  朝向：1 右，-1 左
     */
    public static void draw(Canvas canvas, int template, float w, float h, int st,
                            float time, int mood, int dir) {
        switch (template) {
            case 1: drawShiba(canvas, w, h, st, time, mood, dir); break;
            case 2: drawMonster(canvas, w, h, st, time, mood, dir); break;
            case 3: drawGhost(canvas, w, h, st, time, mood, dir); break;
            default: drawCat(canvas, w, h, st, time, mood, dir); break;
        }
    }

    // ---------- 通用工具 ----------
    private static Paint line(float width, int color) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(width);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setColor(color);
        return p;
    }

    private static Paint fill(int color) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        return p;
    }

    private static int INK = 0xFF3B3A4A;

    private static float bob(int st, float time) {
        switch (st) {
            case ST_WALK: return (float) Math.abs(Math.sin(time * 7.0f)) * 0.045f;
            case ST_DANCE: return (float) Math.abs(Math.sin(time * 9.0f)) * 0.07f;
            case ST_SLEEP: return 0.06f;
            case ST_JUMP: return -0.05f;
            case ST_PLAY: return (float) Math.abs(Math.sin(time * 11.0f)) * 0.08f;
            default: return (float) Math.sin(time * 2.2f) * 0.012f; // 呼吸
        }
    }

    private static boolean isBlink(float time, int st) {
        if (st == ST_SLEEP) return true;
        double ph = (time * 0.55) % 3.4;
        return ph > 3.25;
    }

    // ---------- 1. 小白猫 ----------
    private static void drawCat(Canvas c, float w, float h, int st, float time, int mood, int dir) {
        float cx = w * 0.5f;
        float lw = Math.max(2f, w * 0.028f);
        float bob = -h * bob(st, time);
        c.save();
        c.translate(0, bob);

        // 尾巴
        Paint lp = line(lw, INK);
        float tailA = (float) Math.sin(time * (st == ST_WALK ? 6f : 2.4f)) * 0.45f;
        Path tail = new Path();
        float tx = cx - dir * w * 0.24f, ty = h * 0.72f;
        tail.moveTo(tx, ty);
        tail.quadTo(tx - dir * w * 0.20f, ty - h * (0.14f + tailA * 0.10f),
                tx - dir * w * 0.16f, ty - h * 0.30f);
        c.drawPath(tail, lp);

        // 腿
        float legSwing = (st == ST_WALK) ? (float) Math.sin(time * 7f) * 0.35f : 0f;
        c.drawLine(cx - w * 0.12f, h * 0.90f, cx - w * 0.12f + w * legSwing * 0.35f, h * 0.99f, lp);
        c.drawLine(cx + w * 0.12f, h * 0.90f, cx + w * 0.12f - w * legSwing * 0.35f, h * 0.99f, lp);

        // 身体
        Paint body = fill(0xFFFFFFFF);
        RectF br = new RectF(cx - w * 0.30f, h * 0.54f, cx + w * 0.30f, h * 0.94f);
        c.drawOval(br, body);
        c.drawOval(br, lp);

        // 项圈
        Paint collar = fill(mood > 50 ? 0xFF7C5CFF : 0xFFFF8AC4);
        RectF cr = new RectF(cx - w * 0.22f, h * 0.545f, cx + w * 0.22f, h * 0.60f);
        c.drawOval(cr, collar);

        // 头
        float headR = w * 0.27f;
        float hx = cx, hy = h * 0.36f;
        c.drawCircle(hx, hy, headR, body);
        c.drawCircle(hx, hy, headR, lp);

        // 耳朵
        Path ear1 = new Path();
        ear1.moveTo(hx - headR * 0.85f, hy - headR * 0.45f);
        ear1.lineTo(hx - headR * 0.95f, hy - headR * 1.5f);
        ear1.lineTo(hx - headR * 0.15f, hy - headR * 0.85f);
        ear1.close();
        Path ear2 = new Path();
        ear2.moveTo(hx + headR * 0.85f, hy - headR * 0.45f);
        ear2.lineTo(hx + headR * 0.95f, hy - headR * 1.5f);
        ear2.lineTo(hx + headR * 0.15f, hy - headR * 0.85f);
        ear2.close();
        Paint pink = fill(0xFFFFC9DC);
        c.drawPath(ear1, body); c.drawPath(ear1, lp);
        c.drawPath(ear2, body); c.drawPath(ear2, lp);
        c.drawPath(ear1, pink);
        c.drawPath(ear2, pink);
        c.drawPath(ear1, lp);
        c.drawPath(ear2, lp);

        drawEyes(c, hx, hy, headR, st, time, mood, dir, true);
        drawMouth(c, hx, hy + headR * 0.42f, headR * 0.30f, st, mood);
        // 腮红
        Paint blush = fill(0x55FF9EC4);
        c.drawOval(new RectF(hx - headR * 0.72f, hy + headR * 0.12f, hx - headR * 0.22f, hy + headR * 0.42f), blush);
        c.drawOval(new RectF(hx + headR * 0.22f, hy + headR * 0.12f, hx + headR * 0.72f, hy + headR * 0.42f), blush);
        c.restore();
    }

    // ---------- 2. 柴柴 ----------
    private static void drawShiba(Canvas c, float w, float h, int st, float time, int mood, int dir) {
        float cx = w * 0.5f;
        float lw = Math.max(2f, w * 0.028f);
        c.save();
        c.translate(0, -h * bob(st, time));
        Paint lp = line(lw, INK);
        Paint fur = fill(0xFFF5B169);
        Paint cream = fill(0xFFFFF3E2);

        // 卷尾
        float ta = (float) Math.sin(time * (st == ST_WALK ? 6.5f : 2.6f)) * 0.4f;
        Path tail = new Path();
        float tx = cx - dir * w * 0.22f, ty = h * 0.66f;
        tail.moveTo(tx, ty);
        tail.quadTo(tx - dir * w * (0.24f + ta * 0.06f), ty - h * 0.16f,
                tx - dir * w * 0.06f, ty - h * 0.30f);
        c.drawPath(tail, lp);

        float legSwing = (st == ST_WALK) ? (float) Math.sin(time * 7f) * 0.32f : 0f;
        c.drawLine(cx - w * 0.11f, h * 0.90f, cx - w * 0.11f + w * legSwing * 0.35f, h * 0.99f, lp);
        c.drawLine(cx + w * 0.11f, h * 0.90f, cx + w * 0.11f - w * legSwing * 0.35f, h * 0.99f, lp);

        RectF br = new RectF(cx - w * 0.29f, h * 0.56f, cx + w * 0.29f, h * 0.94f);
        c.drawOval(br, fur); c.drawOval(br, lp);
        RectF belly = new RectF(cx - w * 0.16f, h * 0.68f, cx + w * 0.16f, h * 0.93f);
        c.drawOval(belly, cream);

        float headR = w * 0.26f;
        float hx = cx, hy = h * 0.37f;
        c.drawCircle(hx, hy, headR, fur); c.drawCircle(hx, hy, headR, lp);
        RectF muzzle = new RectF(hx - headR * 0.55f, hy + headR * 0.10f, hx + headR * 0.55f, hy + headR * 0.72f);
        c.drawOval(muzzle, cream);

        // 尖耳
        Path e1 = new Path();
        e1.moveTo(hx - headR * 0.80f, hy - headR * 0.42f);
        e1.lineTo(hx - headR * 0.92f, hy - headR * 1.42f);
        e1.lineTo(hx - headR * 0.08f, hy - headR * 0.80f);
        e1.close();
        Path e2 = new Path();
        e2.moveTo(hx + headR * 0.80f, hy - headR * 0.42f);
        e2.lineTo(hx + headR * 0.92f, hy - headR * 1.42f);
        e2.lineTo(hx + headR * 0.08f, hy - headR * 0.80f);
        e2.close();
        c.drawPath(e1, fur); c.drawPath(e1, lp);
        c.drawPath(e2, fur); c.drawPath(e2, lp);

        drawEyes(c, hx, hy - headR * 0.06f, headR, st, time, mood, dir, true);
        // 鼻子 + 嘴
        Paint nose = fill(0xFF3B3A4A);
        c.drawOval(new RectF(hx - headR * 0.13f, hy + headR * 0.24f, hx + headR * 0.13f, hy + headR * 0.42f), nose);
        drawMouth(c, hx, hy + headR * 0.46f, headR * 0.32f, st, mood);
        c.restore();
    }

    // ---------- 3. 小怪物 ----------
    private static void drawMonster(Canvas c, float w, float h, int st, float time, int mood, int dir) {
        float cx = w * 0.5f;
        float lw = Math.max(2f, w * 0.03f);
        c.save();
        c.translate(0, -h * bob(st, time));
        Paint lp = line(lw, INK);
        Paint body = fill(0xFFA78BFA);

        // 脚
        float legSwing = (st == ST_WALK) ? (float) Math.sin(time * 7f) * 0.3f : 0f;
        c.drawLine(cx - w * 0.12f, h * 0.88f, cx - w * 0.12f + w * legSwing * 0.3f, h * 0.99f, lp);
        c.drawLine(cx + w * 0.12f, h * 0.88f, cx + w * 0.12f - w * legSwing * 0.3f, h * 0.99f, lp);

        float r = w * 0.34f;
        float cy = h * 0.60f;
        c.drawCircle(cx, cy, r, body);
        c.drawCircle(cx, cy, r, lp);

        // 小角
        Path horn = new Path();
        horn.moveTo(cx - r * 0.5f, cy - r * 0.86f);
        horn.lineTo(cx - r * 0.34f, cy - r * 1.42f);
        horn.lineTo(cx - r * 0.10f, cy - r * 0.94f);
        horn.close();
        Path horn2 = new Path();
        horn2.moveTo(cx + r * 0.5f, cy - r * 0.86f);
        horn2.lineTo(cx + r * 0.34f, cy - r * 1.42f);
        horn2.lineTo(cx + r * 0.10f, cy - r * 0.94f);
        horn2.close();
        Paint hornP = fill(0xFFFFD166);
        c.drawPath(horn, hornP); c.drawPath(horn, lp);
        c.drawPath(horn2, hornP); c.drawPath(horn2, lp);

        // 独眼
        float er = r * 0.42f;
        float ex = cx, ey = cy - r * 0.10f;
        Paint white = fill(0xFFFFFFFF);
        c.drawCircle(ex, ey, er, white);
        c.drawCircle(ex, ey, er, lp);
        float pup = er * 0.42f;
        float look = (float) Math.sin(time * 0.9f) * er * 0.18f + dir * er * 0.10f;
        if (!isBlink(time, st)) {
            c.drawCircle(ex + look, ey + er * 0.05f, pup, fill(0xFF2B2A3A));
            c.drawCircle(ex + look - pup * 0.35f, ey - pup * 0.35f, pup * 0.34f, fill(0xFFFFFFFF));
        } else {
            c.drawLine(ex - er * 0.8f, ey, ex + er * 0.8f, ey, lp);
        }

        // 嘴 + 牙
        drawMouth(c, cx, cy + r * 0.42f, r * 0.42f, st, mood);
        Paint tooth = fill(0xFFFFFFFF);
        Path t1 = new Path();
        float my = cy + r * 0.36f;
        t1.moveTo(cx - r * 0.16f, my);
        t1.lineTo(cx - r * 0.04f, my);
        t1.lineTo(cx - r * 0.10f, my + r * 0.18f);
        t1.close();
        c.drawPath(t1, tooth); c.drawPath(t1, lp);
        c.restore();
    }

    // ---------- 4. 小幽灵 ----------
    private static void drawGhost(Canvas c, float w, float h, int st, float time, int mood, int dir) {
        float cx = w * 0.5f;
        float lw = Math.max(2f, w * 0.028f);
        float floatY = (float) Math.sin(time * 1.6f) * h * 0.03f - h * bob(st, time) * 0.5f;
        c.save();
        c.translate(0, floatY);
        Paint lp = line(lw, INK);
        Paint body = fill(0xE8FFFFFF);

        float bw = w * 0.36f, top = h * 0.20f, bot = h * 0.92f;
        Path p = new Path();
        p.moveTo(cx - bw, bot);
        p.lineTo(cx - bw, top + bw * 0.7f);
        p.arcTo(new RectF(cx - bw, top - bw * 0.3f, cx + bw, top + bw * 1.7f), 180f, 180f);
        p.lineTo(cx + bw, bot);
        // 波浪底边
        int waves = 4;
        float step = bw * 2f / waves;
        for (int i = 0; i < waves; i++) {
            float x0 = cx + bw - i * step;
            float amp = h * 0.06f * (float) Math.sin(time * 3f + i);
            p.quadTo(x0 - step * 0.5f, bot + amp, x0 - step, bot);
        }
        p.close();
        c.drawPath(p, body);
        c.drawPath(p, lp);

        float er = bw * 0.24f;
        float ey = top + bw * 0.62f;
        drawEyes(c, cx, ey, bw * 0.86f, st, time, mood, dir, true);
        drawMouth(c, cx, ey + bw * 0.55f, bw * 0.30f, st, mood);
        Paint blush = fill(0x44FF9EC4);
        c.drawOval(new RectF(cx - bw * 0.72f, ey + bw * 0.24f, cx - bw * 0.32f, ey + bw * 0.52f), blush);
        c.drawOval(new RectF(cx + bw * 0.32f, ey + bw * 0.24f, cx + bw * 0.72f, ey + bw * 0.52f), blush);
        c.restore();
    }

    // ---------- 眼睛 / 嘴 ----------
    private static void drawEyes(Canvas c, float hx, float hy, float headR, int st, float time,
                                 int mood, int dir, boolean two) {
        Paint ink = fill(0xFF2B2A3A);
        Paint white = fill(0xFFFFFFFF);
        float er = headR * 0.17f;
        float off = headR * 0.38f;
        if (!two) return;
        if (isBlink(time, st) || st == ST_SLEEP) {
            Paint lp = line(Math.max(1.6f, headR * 0.06f), INK);
            c.drawLine(hx - off - er, hy, hx - off + er, hy, lp);
            c.drawLine(hx + off - er, hy, hx + off + er, hy, lp);
            return;
        }
        float lookX = (float) Math.sin(time * 0.8f) * er * 0.25f + dir * er * 0.12f;
        float scale = (st == ST_STARTLED) ? 1.35f : 1f;
        c.drawOval(new RectF(hx - off - er * scale, hy - er * scale, hx - off + er * scale, hy + er * scale), ink);
        c.drawOval(new RectF(hx + off - er * scale, hy - er * scale, hx + off + er * scale, hy + er * scale), ink);
        c.drawCircle(hx - off + lookX - er * 0.35f, hy - er * 0.4f, er * 0.36f, white);
        c.drawCircle(hx + off + lookX - er * 0.35f, hy - er * 0.4f, er * 0.36f, white);

        // 生气：眉毛
        if (st == ST_ANGRY || mood < 25) {
            Paint lp = line(Math.max(1.8f, headR * 0.07f), INK);
            c.drawLine(hx - off - er * 1.3f, hy - er * 1.7f, hx - off + er * 0.6f, hy - er * 1.0f, lp);
            c.drawLine(hx + off + er * 1.3f, hy - er * 1.7f, hx + off - er * 0.6f, hy - er * 1.0f, lp);
        }
    }

    private static void drawMouth(Canvas c, float mx, float my, float mw, int st, int mood) {
        Paint lp = line(Math.max(1.6f, mw * 0.22f), INK);
        if (st == ST_EAT) {
            Paint dark = fill(0xFF6B4A4A);
            c.drawOval(new RectF(mx - mw * 0.5f, my - mw * 0.18f, mx + mw * 0.5f, my + mw * 0.75f), dark);
            c.drawOval(new RectF(mx - mw * 0.5f, my - mw * 0.18f, mx + mw * 0.5f, my + mw * 0.75f), lp);
            return;
        }
        if (st == ST_ANGRY || mood < 25) {
            Path p = new Path();
            p.moveTo(mx - mw, my + mw * 0.35f);
            p.quadTo(mx, my - mw * 0.45f, mx + mw, my + mw * 0.35f);
            c.drawPath(p, lp);
            return;
        }
        Path p = new Path();
        p.moveTo(mx - mw, my);
        p.quadTo(mx - mw * 0.4f, my + mw * 0.55f, mx, my + mw * 0.08f);
        p.quadTo(mx + mw * 0.4f, my + mw * 0.55f, mx + mw, my);
        c.drawPath(p, lp);
    }

    /** 列表预览用的静态头像 */
    public static void drawPreview(Canvas c, int template, float w, float h) {
        draw(c, template, w, h, ST_IDLE, 0.6f, 90, 1);
    }
}
