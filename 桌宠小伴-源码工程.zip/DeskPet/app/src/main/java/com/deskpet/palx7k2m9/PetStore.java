package com.deskpet.palx7k2m9;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * 宠物数据 + 全局设置，全部存在本地 SharedPreferences，不联网、不上传。
 */
public class PetStore {

    public static final String PREF_PETS = "pets";
    public static final String PREF_SET = "settings";
    public static final String KEY_LIST = "list";

    public static class Pet {
        public String id;
        public String name;
        public int kind = 0;                    // 0=内置模板  1=图片（抠图/相册）
        public int template = 0;                // 内置模板编号
        public ArrayList<String> frames = new ArrayList<String>(); // 图片帧路径
        public float relX = 0.5f, relY = 0.72f; // 相对屏幕的位置比例
        public int sizeDp = 88;                 // 显示大小
        public int mood = 80, hunger = 70, clean = 85;
        public long lastCare = 0;
        public boolean enabled = true;
        public int speed = 100;                 // 移动速度百分比
        public boolean partAnim = true;         // 图片宠物：头身分离摆动
        public int fps = 8;                     // 多帧播放速度

        public JSONObject toJson() {
            try {
                JSONObject o = new JSONObject();
                o.put("id", id);
                o.put("name", name);
                o.put("kind", kind);
                o.put("template", template);
                JSONArray fa = new JSONArray();
                for (String f : frames) fa.put(f);
                o.put("frames", fa);
                o.put("relX", (double) relX);
                o.put("relY", (double) relY);
                o.put("sizeDp", sizeDp);
                o.put("mood", mood);
                o.put("hunger", hunger);
                o.put("clean", clean);
                o.put("lastCare", lastCare);
                o.put("enabled", enabled);
                o.put("speed", speed);
                o.put("partAnim", partAnim);
                o.put("fps", fps);
                return o;
            } catch (Exception e) {
                return new JSONObject();
            }
        }

        public static Pet fromJson(JSONObject o) {
            Pet p = new Pet();
            p.id = o.optString("id", String.valueOf(System.currentTimeMillis()));
            p.name = o.optString("name", "小可爱");
            p.kind = o.optInt("kind", 0);
            p.template = o.optInt("template", 0);
            JSONArray fa = o.optJSONArray("frames");
            if (fa != null) {
                for (int i = 0; i < fa.length(); i++) p.frames.add(fa.optString(i, ""));
            }
            p.relX = (float) o.optDouble("relX", 0.5);
            p.relY = (float) o.optDouble("relY", 0.72);
            p.sizeDp = o.optInt("sizeDp", 88);
            p.mood = o.optInt("mood", 80);
            p.hunger = o.optInt("hunger", 70);
            p.clean = o.optInt("clean", 85);
            p.lastCare = o.optLong("lastCare", 0);
            p.enabled = o.optBoolean("enabled", true);
            p.speed = o.optInt("speed", 100);
            p.partAnim = o.optBoolean("partAnim", true);
            p.fps = o.optInt("fps", 8);
            return p;
        }
    }

    public static class Settings {
        public String bgPath = "";            // 自定义背景图
        public int glassAlpha = 40;           // 玻璃不透明度（越小越透）
        public int scrimAlpha = 10;           // 背景压暗（保证白字可读）
        public float strokeWidth = 2.4f;      // 白字描边粗细 dp
        public int cacheMode = 1;             // 0=A真实统计 1=B清理公共垃圾 2=C纯娱乐
        public boolean eatBadge = true;       // 吞通知角标
        public boolean sleepOnScreenOff = true;
        public boolean followFinger = true;
        public boolean shakeEnabled = true;
        public boolean doubleTap = true;
        public boolean bootStart = false;
        public int walkSpeed = 100;
        public boolean showBubble = true;     // 宠物气泡

        public JSONObject toJson() {
            try {
                JSONObject o = new JSONObject();
                o.put("bgPath", bgPath);
                o.put("glassAlpha", glassAlpha);
                o.put("scrimAlpha", scrimAlpha);
                o.put("strokeWidth", (double) strokeWidth);
                o.put("cacheMode", cacheMode);
                o.put("eatBadge", eatBadge);
                o.put("sleepOnScreenOff", sleepOnScreenOff);
                o.put("followFinger", followFinger);
                o.put("shakeEnabled", shakeEnabled);
                o.put("doubleTap", doubleTap);
                o.put("bootStart", bootStart);
                o.put("walkSpeed", walkSpeed);
                o.put("showBubble", showBubble);
                return o;
            } catch (Exception e) {
                return new JSONObject();
            }
        }

        public static Settings fromJson(JSONObject o) {
            Settings s = new Settings();
            s.bgPath = o.optString("bgPath", "");
            s.glassAlpha = o.optInt("glassAlpha", 40);
            s.scrimAlpha = o.optInt("scrimAlpha", 10);
            s.strokeWidth = (float) o.optDouble("strokeWidth", 2.4);
            s.cacheMode = o.optInt("cacheMode", 1);
            s.eatBadge = o.optBoolean("eatBadge", true);
            s.sleepOnScreenOff = o.optBoolean("sleepOnScreenOff", true);
            s.followFinger = o.optBoolean("followFinger", true);
            s.shakeEnabled = o.optBoolean("shakeEnabled", true);
            s.doubleTap = o.optBoolean("doubleTap", true);
            s.bootStart = o.optBoolean("bootStart", false);
            s.walkSpeed = o.optInt("walkSpeed", 100);
            s.showBubble = o.optBoolean("showBubble", true);
            return s;
        }
    }

    public static List<Pet> loadPets(Context c) {
        List<Pet> list = new ArrayList<Pet>();
        try {
            String s = prefs(c).getString(KEY_LIST, "");
            if (s == null || s.length() == 0) return list;
            JSONArray arr = new JSONArray(s);
            for (int i = 0; i < arr.length(); i++) list.add(Pet.fromJson(arr.getJSONObject(i)));
        } catch (Exception e) {
            // ignore
        }
        return list;
    }

    public static void savePets(Context c, List<Pet> list) {
        try {
            JSONArray arr = new JSONArray();
            for (Pet p : list) arr.put(p.toJson());
            prefs(c).edit().putString(KEY_LIST, arr.toString()).apply();
        } catch (Exception e) {
            // ignore
        }
    }

    public static Settings getSettings(Context c) {
        try {
            String s = setPrefs(c).getString("cfg", "");
            if (s == null || s.length() == 0) return new Settings();
            return Settings.fromJson(new JSONObject(s));
        } catch (Exception e) {
            return new Settings();
        }
    }

    public static void saveSettings(Context c, Settings s) {
        setPrefs(c).edit().putString("cfg", s.toJson().toString()).apply();
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREF_PETS, Context.MODE_PRIVATE);
    }

    private static SharedPreferences setPrefs(Context c) {
        return c.getSharedPreferences(PREF_SET, Context.MODE_PRIVATE);
    }

    public static File petDir(Context c) {
        File d = new File(c.getFilesDir(), "pets");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    public static File newFrameFile(Context c, String petId, int index) {
        File d = new File(petDir(c), petId);
        if (!d.exists()) d.mkdirs();
        return new File(d, "frame_" + index + ".png");
    }
}
