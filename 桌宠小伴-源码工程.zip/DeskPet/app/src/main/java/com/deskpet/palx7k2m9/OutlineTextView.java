package com.deskpet.palx7k2m9;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.widget.TextView;

/**
 * 永远看得清的文字：先画一圈深色描边，再填白色，最后叠一层柔和阴影。
 * 即使背景是纯白，白色文字依然清晰可辨。
 */
public class OutlineTextView extends TextView {

    private float strokeDp = 2.4f;
    private int strokeColor = 0xCC111111;

    public OutlineTextView(Context c) {
        super(c);
        init(c);
    }

    public OutlineTextView(Context c, AttributeSet a) {
        super(c, a);
        init(c);
    }

    public OutlineTextView(Context c, AttributeSet a, int style) {
        super(c, a, style);
        init(c);
    }

    private void init(Context c) {
        try {
            PetStore.Settings s = PetStore.getSettings(c);
            strokeDp = s.strokeWidth;
        } catch (Exception e) {
            // ignore
        }
        applyShadow();
    }

    private void applyShadow() {
        setShadowLayer(Math.max(2f, strokeDp * 1.6f), 0, Math.max(1f, strokeDp * 0.5f), 0x99000000);
    }

    public void setStroke(float dp, int color) {
        strokeDp = dp;
        strokeColor = color;
        applyShadow();
        invalidate();
    }

    public void refreshFromSettings() {
        try {
            PetStore.Settings s = PetStore.getSettings(getContext());
            strokeDp = s.strokeWidth;
        } catch (Exception e) {
            // ignore
        }
        applyShadow();
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        Paint p = getPaint();
        int c = getCurrentTextColor();
        // 第一遍：画描边（直接改 Paint，不用 setTextColor，避免重复触发重绘）
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(strokeDp * getResources().getDisplayMetrics().density);
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setColor(strokeColor);
        super.onDraw(canvas);
        // 第二遍：填字
        p.setStyle(Paint.Style.FILL);
        p.setColor(c);
        super.onDraw(canvas);
    }
}
