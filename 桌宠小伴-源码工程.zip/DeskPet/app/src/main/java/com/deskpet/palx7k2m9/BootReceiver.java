package com.deskpet.palx7k2m9;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (i == null) return;
        String a = i.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(a)
                || Intent.ACTION_USER_PRESENT.equals(a)
                || Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)) {
            PetStore.Settings s = PetStore.getSettings(c);
            if (!s.bootStart) return;
            try {
                Intent sv = new Intent(c, PetService.class);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    c.startForegroundService(sv);
                } else {
                    c.startService(sv);
                }
            } catch (Exception e) {
                // ignore
            }
        }
    }
}
