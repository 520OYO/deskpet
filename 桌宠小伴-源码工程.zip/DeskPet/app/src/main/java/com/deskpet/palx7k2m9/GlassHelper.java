package com.deskpet.palx7k2m9;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;

/**
 * 液态玻璃 UI 工具：统一生成半透明玻璃卡片、白字描边标题、玻璃按钮。
 * 透明度由设置控制，保证背景图清晰可见。
 */
public class GlassHelper {

    public static int dp(Context c, float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                c.getResources().getDisplayMetrics());
    }

    public static LinearLayout card(Context c, int padDp) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackgroundResource(R.drawable.glass_card);
        int p = dp(c, padDp);
        l.setPadding(p, p, p, p);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(c, 10);
        l.setLayoutParams(lp);
        applyAlpha(c, l);
        return l;
    }

    public static LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        l.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return l;
    }

    /** 只调整背景的透明度，不影响文字清晰度 */
    public static void applyAlpha(Context c, View v) {
        PetStore.Settings s = PetStore.getSettings(c);
        Drawable d = v.getBackground();
        if (d != null) {
            d = d.mutate();
            d.setAlpha(Math.round(255 * (s.glassAlpha / 100f)));
            v.setBackground(d);
        }
    }

    public static OutlineTextView title(Context c, String text, float sp) {
        OutlineTextView t = new OutlineTextView(c);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(0xFFFFFFFF);
        t.setTypeface(null, android.graphics.Typeface.BOLD);
        t.refreshFromSettings();
        return t;
    }

    public static OutlineTextView label(Context c, String text, float sp) {
        OutlineTextView t = new OutlineTextView(c);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(0xF2FFFFFF);
        t.refreshFromSettings();
        return t;
    }

    public static Button button(Context c, String text, boolean accent) {
        Button b = new Button(c);
        b.setText(text);
        b.setTextColor(0xFFFFFFFF);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setBackgroundResource(accent ? R.drawable.glass_button_accent : R.drawable.glass_button);
        b.setPadding(dp(c, 14), 0, dp(c, 14), 0);
        b.setMinHeight(dp(c, 40));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(c, 40));
        lp.rightMargin = dp(c, 6);
        b.setLayoutParams(lp);
        return b;
    }

    public static Button wide(Context c, String text, boolean accent) {
        Button b = button(c, text, accent);
        b.setLayoutParams(new LinearLayout.LayoutParams(0, dp(c, 42), 1f));
        return b;
    }

    public static Switch sw(Context c, String text, boolean checked) {
        Switch s = new Switch(c);
        s.setText(text);
        s.setTextColor(0xFFFFFFFF);
        s.setTextSize(14);
        s.setChecked(checked);
        return s;
    }

    /** 应用自定义背景图 + 压暗层（保证白字可读） */
    public static void applyBackground(Context c, ImageView bg, View scrim) {
        PetStore.Settings s = PetStore.getSettings(c);
        if (s.bgPath != null && s.bgPath.length() > 0) {
            Bitmap b = BitmapFactory2.decode(s.bgPath);
            if (b != null) {
                bg.setImageBitmap(b);
            }
        }
        if (scrim != null) {
            scrim.setBackgroundColor(0x00000000 | (Math.round(255 * (s.scrimAlpha / 100f)) << 24));
        }
    }

    /** 把内置宠物画成预览小图 */
    public static Bitmap previewOf(int template, int sizePx) {
        Bitmap b = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        PetArt.drawPreview(c, template, sizePx, sizePx);
        return b;
    }

    public static class BitmapFactory2 {
        public static Bitmap decode(String path) {
            try {
                android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                android.graphics.BitmapFactory.decodeFile(path, o);
                int max = 1600;
                int s = 1;
                while (Math.max(o.outWidth, o.outHeight) / s > max) s *= 2;
                o.inJustDecodeBounds = false;
                o.inSampleSize = s;
                return android.graphics.BitmapFactory.decodeFile(path, o);
            } catch (Exception e) {
                return null;
            }
        }
    }
}
