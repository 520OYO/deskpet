package com.deskpet.palx7k2m9;

import android.app.Notification;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * "吞掉角标"：读取状态栏通知，宠物吃掉后调用系统接口取消该通知，
 * 桌面图标右上角的数字角标随之消失。只做取消，不读取通知内容以外的任何隐私。
 */
public class NotifEatService extends NotificationListenerService {

    public static final String ACTION_UPDATE = "com.deskpet.palx7k2m9.NOTIF_UPDATE";
    private static NotifEatService instance = null;
    private static final ArrayList<StatusBarNotification> pending = new ArrayList<StatusBarNotification>();
    private static final HashMap<String, String> labels = new HashMap<String, String>();

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
    }

    @Override
    public void onDestroy() {
        instance = null;
        super.onDestroy();
    }

    @Override
    public void onListenerConnected() {
        super.onListenerConnected();
        try {
            StatusBarNotification[] arr = getActiveNotifications();
            if (arr != null) {
                pending.clear();
                for (StatusBarNotification s : arr) add(s);
            }
        } catch (Exception e) {
            // ignore
        }
        notifyUi();
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (add(sbn)) notifyUi();
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        if (sbn == null) return;
        String key = key(sbn);
        for (int i = pending.size() - 1; i >= 0; i--) {
            if (key(pending.get(i)).equals(key)) pending.remove(i);
        }
        notifyUi();
    }

    private boolean add(StatusBarNotification sbn) {
        if (sbn == null) return false;
        try {
            if (!sbn.isClearable()) return false;                       // 常驻通知不吞
            Notification n = sbn.getNotification();
            if (n != null && (n.flags & Notification.FLAG_ONGOING_EVENT) != 0) return false;
        } catch (Exception e) {
            return false;
        }
        if (getPackageName().equals(sbn.getPackageName())) return false; // 自己的通知不吞
        String k = key(sbn);
        for (StatusBarNotification s : pending) if (key(s).equals(k)) return false;
        pending.add(sbn);
        return true;
    }

    private static String key(StatusBarNotification sbn) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) return sbn.getKey();
        return sbn.getPackageName() + "|" + sbn.getId();
    }

    private void notifyUi() {
        try {
            sendBroadcast(new Intent(ACTION_UPDATE));
        } catch (Exception e) {
            // ignore
        }
    }

    public static int pendingCount() {
        return pending.size();
    }

    /** 吃掉一条通知，返回被吃掉的来源名 */
    public static String eatOne(Context c) {
        if (instance == null || pending.isEmpty()) return null;
        StatusBarNotification sbn = pending.remove(0);
        String pkg = sbn.getPackageName();
        String name = appLabel(c, pkg);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                instance.cancelNotification(sbn.getKey());
            } else {
                instance.cancelNotification(pkg, sbn.getTag(), sbn.getId());
            }
        } catch (Exception e) {
            return null;
        }
        notifyStatic(c);
        return name;
    }

    private static void notifyStatic(Context c) {
        try {
            c.sendBroadcast(new Intent(ACTION_UPDATE));
        } catch (Exception e) {
            // ignore
        }
    }

    public static String appLabel(Context c, String pkg) {
        if (labels.containsKey(pkg)) return labels.get(pkg);
        String n = pkg;
        try {
            PackageManager pm = c.getPackageManager();
            n = pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString();
        } catch (Exception e) {
            // ignore
        }
        labels.put(pkg, n);
        return n;
    }

    public static ArrayList<String> pendingNames(Context c) {
        ArrayList<String> out = new ArrayList<String>();
        for (StatusBarNotification s : pending) out.add(appLabel(c, s.getPackageName()));
        return out;
    }

    public static boolean isEnabled(Context c) {
        try {
            String flat = android.provider.Settings.Secure.getString(c.getContentResolver(),
                    "enabled_notification_listeners");
            if (flat == null || flat.length() == 0) return false;
            return flat.contains(c.getPackageName());
        } catch (Exception e) {
            return false;
        }
    }
}
