package com.deskpet.palx7k2m9;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.AnimationDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * 抠图工坊：把你相册里的图（人物、猫狗、表情包、AI 生成的图）抠成透明底，
 * 可以再加几帧不同姿势，保存后就是一只能跑能跳的桌宠。
 */
public class CutoutActivity extends Activity {

    private static final int REQ_PICK = 3001;
    private CutoutView cut;
    private ImageView previewBg;
    private SeekBar seekTol;
    private OutlineTextView tip;
    private ArrayList<Bitmap> savedFrames = new ArrayList<Bitmap>();
    private String petId = null;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_cutout);
        cut = findViewById(R.id.cutout);
        previewBg = findViewById(R.id.preview_bg);
        seekTol = findViewById(R.id.seek_tol);
        tip = findViewById(R.id.tip);

        Button pick = findViewById(R.id.btn_pick);
        Button auto = findViewById(R.id.btn_auto);
        Button mode = findViewById(R.id.btn_mode);
        Button back = findViewById(R.id.btn_back);
        Button addFrame = findViewById(R.id.btn_add_frame);
        Button preview = findViewById(R.id.btn_preview);
        Button save = findViewById(R.id.btn_save);

        pick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickImage();
            }
        });
        auto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!cut.hasImage()) {
                    Toast.makeText(CutoutActivity.this, "先选一张图片", Toast.LENGTH_SHORT).show();
                    return;
                }
                cut.autoCut(seekTol.getProgress());
                tip.setText("抠好啦！紫色框内是你留下的部分，用擦除/保留修补细节。");
            }
        });
        mode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int m = cut.getMode() == CutoutView.MODE_ERASE ? CutoutView.MODE_KEEP : CutoutView.MODE_ERASE;
                cut.setMode(m);
                ((Button) v).setText(m == CutoutView.MODE_ERASE ? "擦除" : "保留");
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        addFrame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bitmap r = cut.result();
                if (r == null) {
                    Toast.makeText(CutoutActivity.this, "还没有可保存的图", Toast.LENGTH_SHORT).show();
                    return;
                }
                savedFrames.add(r);
                cut.clearResult();
                Toast.makeText(CutoutActivity.this, "已存第 " + savedFrames.size() + " 帧，再选一张图做下一帧吧", Toast.LENGTH_LONG).show();
                pickImage();
            }
        });
        preview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPreview();
            }
        });
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                askNameAndSave();
            }
        });
    }

    private void pickImage() {
        Intent it = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        it.addCategory(Intent.CATEGORY_OPENABLE);
        it.setType("image/*");
        try {
            startActivityForResult(it, REQ_PICK);
        } catch (Exception e) {
            Toast.makeText(this, "打不开相册，试试文件管理器选图", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_PICK && res == RESULT_OK && data != null && data.getData() != null) {
            Bitmap b = loadBitmap(data.getData());
            if (b == null) {
                Toast.makeText(this, "图片读取失败", Toast.LENGTH_SHORT).show();
                return;
            }
            cut.setSource(b);
            previewBg.setImageBitmap(b);
            previewBg.setAlpha(60);
            cut.autoCut(seekTol.getProgress());
            tip.setText("已自动抠图。调上面的滑杆再点「智能抠图」可以抠得更干净。");
        }
    }

    private Bitmap loadBitmap(android.net.Uri uri) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(getContentResolver().openInputStream(uri), null, o);
            int max = 1400;
            int s = 1;
            while (Math.max(o.outWidth, o.outHeight) / s > max) s *= 2;
            o.inJustDecodeBounds = false;
            o.inSampleSize = s;
            return BitmapFactory.decodeStream(getContentResolver().openInputStream(uri), null, o);
        } catch (Exception e) {
            return null;
        }
    }

    private void showPreview() {
        final ArrayList<Bitmap> all = new ArrayList<Bitmap>(savedFrames);
        Bitmap cur = cut.result();
        if (cur != null) all.add(cur);
        if (all.isEmpty()) {
            Toast.makeText(this, "还没有图，先选一张", Toast.LENGTH_SHORT).show();
            return;
        }
        final ImageView iv = new ImageView(this);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        int pad = GlassHelper.dp(this, 16);
        iv.setPadding(pad, pad, pad, pad);
        final AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle("它动起来的样子")
                .setView(iv)
                .setPositiveButton("好", null)
                .show();

        if (all.size() > 1) {
            final AnimationDrawable ad = new AnimationDrawable();
            int dur = Math.max(80, 1000 / Math.max(1, 8));
            for (Bitmap b : all) ad.addFrame(new android.graphics.drawable.BitmapDrawable(getResources(), b), dur);
            ad.setOneShot(false);
            iv.setImageDrawable(ad);
            ad.start();
        } else {
            iv.setImageBitmap(all.get(0));
            // 单帧也能动：程序化弹跳 + 摇摆
            Animation ta = new TranslateAnimation(0, 0, -GlassHelper.dp(this, 10), GlassHelper.dp(this, 6));
            ta.setDuration(420);
            ta.setRepeatCount(Animation.INFINITE);
            ta.setRepeatMode(Animation.REVERSE);
            iv.startAnimation(ta);
        }
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    dlg.dismiss();
                } catch (Exception e) {
                    // ignore
                }
            }
        }, 6000);
    }

    private void askNameAndSave() {
        final ArrayList<Bitmap> all = new ArrayList<Bitmap>(savedFrames);
        Bitmap cur = cut.result();
        if (cur != null) all.add(cur);
        if (all.isEmpty()) {
            Toast.makeText(this, "还没有图，先选一张", Toast.LENGTH_SHORT).show();
            return;
        }
        final EditText et = new EditText(this);
        et.setText("我的宠物");
        et.setSingleLine(true);
        new AlertDialog.Builder(this)
                .setTitle("给它起个名字")
                .setView(et)
                .setPositiveButton("保存", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        savePet(et.getText().toString(), all);
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void savePet(String name, ArrayList<Bitmap> frames) {
        petId = "pet_" + System.currentTimeMillis();
        ArrayList<String> paths = new ArrayList<String>();
        for (int i = 0; i < frames.size(); i++) {
            File f = PetStore.newFrameFile(this, petId, i);
            try {
                FileOutputStream fo = new FileOutputStream(f);
                frames.get(i).compress(Bitmap.CompressFormat.PNG, 100, fo);
                fo.flush();
                fo.close();
                paths.add(f.getAbsolutePath());
            } catch (Exception e) {
                // ignore
            }
        }
        if (paths.isEmpty()) {
            Toast.makeText(this, "保存失败", Toast.LENGTH_SHORT).show();
            return;
        }
        PetStore.Pet p = new PetStore.Pet();
        p.id = petId;
        p.name = name.length() > 0 ? name : "我的宠物";
        p.kind = 1;
        p.frames = paths;
        p.relX = 0.35f + (float) Math.random() * 0.3f;
        p.relY = 0.62f + (float) Math.random() * 0.22f;
        p.sizeDp = 96;
        p.enabled = true;
        p.partAnim = true;

        List<PetStore.Pet> list = PetStore.loadPets(this);
        list.add(p);
        PetStore.savePets(this, list);

        Intent it = new Intent(this, PetService.class);
        it.setAction(PetService.ACTION_REFRESH);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(it);
            else startService(it);
        } catch (Exception e) {
            // ignore
        }
        MainActivity.PetServiceHolder.isRunning = true;
        Toast.makeText(this, "保存成功！它已经跑到桌面上了", Toast.LENGTH_LONG).show();
        finish();
    }
}
