package com.deskpet.palx7k2m9;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayDeque;

/**
 * 抠图画板：智能抠背景（从四边洪水填充）+ 手动擦除/保留。
 * 全程本地处理，不联网，不上传。
 */
public class CutoutView extends View {

    public static final int MODE_ERASE = 0, MODE_KEEP = 1;

    private Bitmap src;          // 缩放后的原图
    private Bitmap out;          // 抠图结果（带透明通道）
    private Canvas outCanvas;
    private RectF dst = new RectF();
    private int mode = MODE_ERASE;
    private float brushDp = 34f;
    private float lastX, lastY;
    private Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Paint erasePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Paint keepPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Paint checkPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    public CutoutView(Context c) {
        super(c);
        init();
    }

    public CutoutView(Context c, AttributeSet a) {
        super(c, a);
        init();
    }

    private void init() {
        erasePaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        erasePaint.setStyle(Paint.Style.FILL);
        keepPaint.setStyle(Paint.Style.FILL);
    }

    public void setSource(Bitmap b) {
        if (b == null) return;
        int maxSide = 900;
        float sc = Math.min(1f, maxSide / (float) Math.max(b.getWidth(), b.getHeight()));
        int w = Math.max(1, (int) (b.getWidth() * sc));
        int h = Math.max(1, (int) (b.getHeight() * sc));
        src = Bitmap.createScaledBitmap(b, w, h, true);
        out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        outCanvas = new Canvas(out);
        outCanvas.drawBitmap(src, 0, 0, null);
        keepPaint.setShader(new BitmapShader(src, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
        computeDst();
        invalidate();
    }

    public boolean hasImage() {
        return src != null && out != null;
    }

    public void setMode(int m) {
        mode = m;
    }

    public int getMode() {
        return mode;
    }

    private void computeDst() {
        if (src == null) return;
        float vw = getWidth(), vh = getHeight();
        if (vw <= 0 || vh <= 0) return;
        float s = Math.min(vw / src.getWidth(), vh / src.getHeight()) * 0.92f;
        float dw = src.getWidth() * s, dh = src.getHeight() * s;
        dst.set((vw - dw) / 2f, (vh - dh) / 2f, (vw - dw) / 2f + dw, (vh - dh) / 2f + dh);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        computeDst();
    }

    /** 智能抠图：从四边开始洪水填充，颜色相近的视为背景 */
    public void autoCut(int tolPercent) {
        if (out == null) return;
        int w = out.getWidth(), h = out.getHeight();
        int[] px = new int[w * h];
        out.getPixels(px, 0, w, 0, 0, w, h);
        boolean[] visited = new boolean[w * h];
        boolean[] bg = new boolean[w * h];
        float tol = tolPercent * 2.6f + 12f;
        ArrayDeque<Integer> q = new ArrayDeque<Integer>();

        // 以四边的像素颜色作为背景参考
        int[] seeds = new int[(w + h) * 4 + 8];
        int sn = 0;
        for (int x = 0; x < w; x++) {
            seeds[sn++] = x;
            seeds[sn++] = 0;
            seeds[sn++] = x;
            seeds[sn++] = h - 1;
        }
        for (int y = 0; y < h; y++) {
            seeds[sn++] = 0;
            seeds[sn++] = y;
            seeds[sn++] = w - 1;
            seeds[sn++] = y;
        }
        for (int i = 0; i + 1 < sn; i += 2) {
            int x = seeds[i], y = seeds[i + 1];
            int idx = y * w + x;
            if (!visited[idx]) {
                visited[idx] = true;
                bg[idx] = true;
                q.add(idx);
            }
        }

        int[] dxy = {1, 0, -1, 0, 0, 1, 0, -1};
        while (!q.isEmpty()) {
            int idx = q.remove();
            int x = idx % w, y = idx / w;
            int c = px[idx];
            for (int k = 0; k < 4; k++) {
                int nx = x + dxy[k * 2], ny = y + dxy[k * 2 + 1];
                if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
                int ni = ny * w + nx;
                if (visited[ni]) continue;
                int nc = px[ni];
                if (colorDist(c, nc) < tol) {
                    visited[ni] = true;
                    bg[ni] = true;
                    q.add(ni);
                }
            }
        }

        for (int i = 0; i < px.length; i++) {
            if (bg[i]) {
                px[i] = px[i] & 0x00FFFFFF;   // alpha = 0
            }
        }
        out.setPixels(px, 0, w, 0, 0, w, h);
        invalidate();
    }

    private static float colorDist(int a, int b) {
        int dr = ((a >> 16) & 0xFF) - ((b >> 16) & 0xFF);
        int dg = ((a >> 8) & 0xFF) - ((b >> 8) & 0xFF);
        int db = (a & 0xFF) - (b & 0xFF);
        return (float) Math.sqrt(dr * dr + dg * dg + db * db);
    }

    /** 导出结果（自动裁掉空白） */
    public Bitmap result() {
        if (out == null) return null;
        int w = out.getWidth(), h = out.getHeight();
        int left = w, top = h, right = 0, bottom = 0;
        int[] px = new int[w * h];
        out.getPixels(px, 0, w, 0, 0, w, h);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                if ((px[y * w + x] >>> 24) > 8) {
                    if (x < left) left = x;
                    if (x > right) right = x;
                    if (y < top) top = y;
                    if (y > bottom) bottom = y;
                }
            }
        }
        if (right <= left || bottom <= top) return null;
        return Bitmap.createBitmap(out, left, top, right - left + 1, bottom - top + 1);
    }

    public Bitmap current() {
        return out;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (out == null) return false;
        float x = e.getX(), y = e.getY();
        switch (e.getAction()) {
            case MotionEvent.ACTION_DOWN:
                lastX = x;
                lastY = y;
                paintAt(x, y);
                return true;
            case MotionEvent.ACTION_MOVE:
                float steps = Math.max(Math.abs(x - lastX), Math.abs(y - lastY));
                int n = (int) Math.max(1, steps / 6);
                for (int i = 1; i <= n; i++) {
                    paintAt(lastX + (x - lastX) * i / n, lastY + (y - lastY) * i / n);
                }
                lastX = x;
                lastY = y;
                invalidate();
                return true;
        }
        return true;
    }

    private void paintAt(float vx, float vy) {
        if (out == null || dst.width() <= 0) return;
        float sx = (vx - dst.left) / dst.width() * out.getWidth();
        float sy = (vy - dst.top) / dst.height() * out.getHeight();
        float r = brushDp * getResources().getDisplayMetrics().density
                * (out.getWidth() / dst.width());
        if (mode == MODE_ERASE) {
            outCanvas.drawCircle(sx, sy, r, erasePaint);
        } else {
            Paint p = keepPaint;
            p.setShader(new BitmapShader(src, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
            Matrix m = new Matrix();
            p.getShader().setLocalMatrix(m);
            outCanvas.drawCircle(sx, sy, r, p);
        }
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        // 棋盘格：表示透明区域
        int grid = 24;
        for (int y = 0; y < getHeight(); y += grid) {
            for (int x = 0; x < getWidth(); x += grid) {
                checkPaint.setColor(((x / grid + y / grid) % 2 == 0) ? 0xFF2A2A34 : 0xFF22222B);
                c.drawRect(x, y, x + grid, y + grid, checkPaint);
            }
        }
        if (out != null) {
            c.drawBitmap(out, null, dst, paint);
        }
        if (mode == MODE_KEEP) {
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2f);
            paint.setColor(0x887C5CFF);
            c.drawRect(dst, paint);
            paint.setStyle(Paint.Style.FILL);
        }
    }

    public void clearResult() {
        if (out != null && src != null) {
            outCanvas.drawBitmap(src, 0, 0, null);
            invalidate();
        }
    }
}
