package com.deskpet.palx7k2m9;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayDeque;

/**
 * 抠图画板：智能抠背景（从四边洪水填充）+ 手动擦除/保留。
 * 全程本地处理，不联网，不上传。
 */
public class CutoutView extends View {

    public static final int MODE_ERASE = 0, MODE_KEEP = 1;

    private Bitmap src;          // 缩放后的原图
    private Bitmap out;          // 抠图结果（带透明通道）
    private Canvas outCanvas;
    private RectF dst = new RectF();
    private int mode = MODE_ERASE;
    private float brushDp = 34f;
    private float lastX, lastY;
    private Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Paint erasePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Paint keepPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Paint checkPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    public CutoutView(Context c) {
        super(c);
        init();
    }

    public CutoutView(Context c, AttributeSet a) {
        super(c, a);
        init();
    }

    private void init() {
        erasePaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        erasePaint.setStyle(Paint.Style.FILL);
        keepPaint.setStyle(Paint.Style.FILL);
    }

    public void setSource(Bitmap b) {
        if (b == null) return;
        int maxSide = 1100;
        float sc = Math.min(1f, maxSide / (float) Math.max(b.getWidth(), b.getHeight()));
        int w = Math.max(1, (int) (b.getWidth() * sc));
        int h = Math.max(1, (int) (b.getHeight() * sc));
        src = Bitmap.createScaledBitmap(b, w, h, true);
        out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        outCanvas = new Canvas(out);
        outCanvas.drawBitmap(src, 0, 0, null);
        keepPaint.setShader(new BitmapShader(src, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
        computeDst();
        invalidate();
    }

    public boolean hasImage() {
        return src != null && out != null;
    }

    public void setMode(int m) {
        mode = m;
    }

    public int getMode() {
        return mode;
    }

    private void computeDst() {
        if (src == null) return;
        float vw = getWidth(), vh = getHeight();
        if (vw <= 0 || vh <= 0) return;
        float s = Math.min(vw / src.getWidth(), vh / src.getHeight()) * 0.92f;
        float dw = src.getWidth() * s, dh = src.getHeight() * s;
        dst.set((vw - dw) / 2f, (vh - dh) / 2f, (vw - dw) / 2f + dw, (vh - dh) / 2f + dh);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        computeDst();
    }

    /**
     * 智能抠图：
     * 1) 四边取样，统计出背景主色（支持渐变/多色背景）
     * 2) 用「全局背景色比对」做洪水填充，避免顺着渐变把人物内部一起吃掉
     * 3) 补回被人物包围的内部孔洞
     * 4) 找回被误删的轮廓边缘（颜色接近前景的过渡像素）
     */
    public void autoCut(int tolPercent) {
        if (out == null || src == null) return;
        int w = out.getWidth(), h = out.getHeight();
        int n = w * h;
        int[] px = new int[n];
        out.getPixels(px, 0, w, 0, 0, w, h);
        // 已被擦掉的区域用原图颜色补齐，保证判断准确，同时保留手动修改
        int[] sp = new int[n];
        src.getPixels(sp, 0, w, 0, 0, w, h);
        for (int i = 0; i < n; i++) {
            if ((px[i] >>> 24) == 0) px[i] = sp[i] & 0x00FFFFFF;
        }

        float tol = tolPercent * 3.0f + 14f;
        int[] refs = sampleBackground(px, w, h);

        boolean[] bg = null;
        for (int attempt = 0; attempt < 3; attempt++) {
            float t = attempt == 0 ? tol : (attempt == 1 ? tol * 0.6f : tol * 0.35f);
            bg = floodBg(px, refs, w, h, t);
            int c = 0;
            for (int i = 0; i < n; i++) if (bg[i]) c++;
            if (c < n * 0.88f) break;      // 删掉太多说明容差过大，收紧重来
        }

        fillHoles(bg, w, h);
        recoverEdge(px, bg, w, h);

        for (int i = 0; i < n; i++) {
            if (bg[i]) px[i] = px[i] & 0x00FFFFFF;
        }
        out.setPixels(px, 0, w, 0, 0, w, h);
        invalidate();
    }

    /** 从四条边取样，统计出现最多的几种颜色作为背景参考色 */
    private static int[] sampleBackground(int[] px, int w, int h) {
        int cap = 4096;
        int[] samples = new int[cap];
        int sc = 0;
        int step = Math.max(1, Math.min(w, h) / 100);
        for (int x = 0; x < w && sc < cap - 2; x += step) {
            samples[sc++] = px[x];
            samples[sc++] = px[(h - 1) * w + x];
        }
        for (int y = 0; y < h && sc < cap - 2; y += step) {
            samples[sc++] = px[y * w];
            samples[sc++] = px[y * w + w - 1];
        }
        int[] cnt = new int[32768];
        for (int i = 0; i < sc; i++) cnt[qkey(samples[i])]++;

        int[] refs = new int[6];
        int rn = 0;
        for (int t = 0; t < 24 && rn < refs.length; t++) {
            int best = -1, bestC = 2;
            for (int k = 0; k < cnt.length; k++) {
                if (cnt[k] > bestC) { bestC = cnt[k]; best = k; }
            }
            if (best < 0) break;
            cnt[best] = 0;
            long r = 0, g = 0, b = 0, m = 0;
            for (int i = 0; i < sc; i++) {
                if (qkey(samples[i]) == best) {
                    r += (samples[i] >> 16) & 0xFF;
                    g += (samples[i] >> 8) & 0xFF;
                    b += samples[i] & 0xFF;
                    m++;
                }
            }
            if (m == 0) continue;
            int c = 0xFF000000 | ((int) (r / m) << 16) | ((int) (g / m) << 8) | (int) (b / m);
            boolean dup = false;
            for (int i = 0; i < rn; i++) if (colorDist(refs[i], c) < 26) dup = true;
            if (dup) continue;
            refs[rn++] = c;
        }
        if (rn == 0) { refs[0] = px[0] | 0xFF000000; rn = 1; }
        int[] res = new int[rn];
        System.arraycopy(refs, 0, res, 0, rn);
        return res;
    }

    private static int qkey(int c) {
        return ((((c >> 16) & 0xFF) >> 3) << 10) | ((((c >> 8) & 0xFF) >> 3) << 5) | (((c & 0xFF) >> 3));
    }

    /** 从四边洪水填充，只吞掉「和背景参考色接近」的连通区域 */
    private static boolean[] floodBg(int[] px, int[] refs, int w, int h, float tol) {
        int n = w * h;
        float[] dist = new float[n];
        for (int i = 0; i < n; i++) {
            float d = 1e9f;
            for (int r = 0; r < refs.length; r++) {
                float t = colorDist(px[i], refs[r]);
                if (t < d) d = t;
            }
            dist[i] = d;
        }
        boolean[] bg = new boolean[n];
        int[] q = new int[n];
        int qh = 0, qt = 0;
        for (int x = 0; x < w; x++) {
            int a = x, b = (h - 1) * w + x;
            if (!bg[a] && dist[a] < tol) { bg[a] = true; q[qt++] = a; }
            if (!bg[b] && dist[b] < tol) { bg[b] = true; q[qt++] = b; }
        }
        for (int y = 0; y < h; y++) {
            int a = y * w, b = y * w + w - 1;
            if (!bg[a] && dist[a] < tol) { bg[a] = true; q[qt++] = a; }
            if (!bg[b] && dist[b] < tol) { bg[b] = true; q[qt++] = b; }
        }
        int[] dxy = {1, 0, -1, 0, 0, 1, 0, -1};
        while (qh < qt) {
            int idx = q[qh++];
            int x = idx % w, y = idx / w;
            for (int k = 0; k < 4; k++) {
                int nx = x + dxy[k * 2], ny = y + dxy[k * 2 + 1];
                if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
                int ni = ny * w + nx;
                if (bg[ni]) continue;
                if (dist[ni] < tol) { bg[ni] = true; q[qt++] = ni; }
            }
        }
        return bg;
    }

    /** 被人物包围的背景（内部孔洞）补回前景，避免身上出现透明窟窿 */
    private static void fillHoles(boolean[] bg, int w, int h) {
        int n = w * h;
        boolean[] ext = new boolean[n];
        int[] q = new int[n];
        int qh = 0, qt = 0;
        for (int x = 0; x < w; x++) {
            int a = x, b = (h - 1) * w + x;
            if (bg[a] && !ext[a]) { ext[a] = true; q[qt++] = a; }
            if (bg[b] && !ext[b]) { ext[b] = true; q[qt++] = b; }
        }
        for (int y = 0; y < h; y++) {
            int a = y * w, b = y * w + w - 1;
            if (bg[a] && !ext[a]) { ext[a] = true; q[qt++] = a; }
            if (bg[b] && !ext[b]) { ext[b] = true; q[qt++] = b; }
        }
        int[] dxy = {1, 0, -1, 0, 0, 1, 0, -1};
        while (qh < qt) {
            int idx = q[qh++];
            int x = idx % w, y = idx / w;
            for (int k = 0; k < 4; k++) {
                int nx = x + dxy[k * 2], ny = y + dxy[k * 2 + 1];
                if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
                int ni = ny * w + nx;
                if (!bg[ni] || ext[ni]) continue;
                ext[ni] = true;
                q[qt++] = ni;
            }
        }
        for (int i = 0; i < n; i++) if (bg[i] && !ext[i]) bg[i] = false;
    }

    /** 轮廓找回：颜色贴近前景的过渡像素不再当成背景，修掉被啃掉的边缘线条 */
    private static void recoverEdge(int[] px, boolean[] bg, int w, int h) {
        int[] dxy = {1, 0, -1, 0, 0, 1, 0, -1};
        int[] buf = new int[Math.max(1024, w * h / 4)];
        for (int round = 0; round < 2; round++) {
            int bn = 0;
            for (int y = 1; y < h - 1 && bn < buf.length; y++) {
                for (int x = 1; x < w - 1 && bn < buf.length; x++) {
                    int i = y * w + x;
                    if (!bg[i]) continue;
                    for (int k = 0; k < 4; k++) {
                        int ni = (y + dxy[k * 2 + 1]) * w + (x + dxy[k * 2]);
                        if (bg[ni]) continue;
                        if (colorDist(px[i], px[ni]) < 55) { buf[bn++] = i; break; }
                    }
                }
            }
            if (bn == 0) break;
            for (int j = 0; j < bn; j++) bg[buf[j]] = false;
        }
    }

    private static float colorDist(int a, int b) {
        int dr = ((a >> 16) & 0xFF) - ((b >> 16) & 0xFF);
        int dg = ((a >> 8) & 0xFF) - ((b >> 8) & 0xFF);
        int db = (a & 0xFF) - (b & 0xFF);
        return (float) Math.sqrt(dr * dr + dg * dg + db * db);
    }

    /** 导出结果（自动裁掉空白） */
    public Bitmap result() {
        if (out == null) return null;
        int w = out.getWidth(), h = out.getHeight();
        int left = w, top = h, right = 0, bottom = 0;
        int[] px = new int[w * h];
        out.getPixels(px, 0, w, 0, 0, w, h);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                if ((px[y * w + x] >>> 24) > 8) {
                    if (x < left) left = x;
                    if (x > right) right = x;
                    if (y < top) top = y;
                    if (y > bottom) bottom = y;
                }
            }
        }
        if (right <= left || bottom <= top) return null;
        return Bitmap.createBitmap(out, left, top, right - left + 1, bottom - top + 1);
    }

    public Bitmap current() {
        return out;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (out == null) return false;
        float x = e.getX(), y = e.getY();
        switch (e.getAction()) {
            case MotionEvent.ACTION_DOWN:
                lastX = x;
                lastY = y;
                paintAt(x, y);
                return true;
            case MotionEvent.ACTION_MOVE:
                float steps = Math.max(Math.abs(x - lastX), Math.abs(y - lastY));
                int n = (int) Math.max(1, steps / 6);
                for (int i = 1; i <= n; i++) {
                    paintAt(lastX + (x - lastX) * i / n, lastY + (y - lastY) * i / n);
                }
                lastX = x;
                lastY = y;
                invalidate();
                return true;
        }
        return true;
    }

    private void paintAt(float vx, float vy) {
        if (out == null || dst.width() <= 0) return;
        float sx = (vx - dst.left) / dst.width() * out.getWidth();
        float sy = (vy - dst.top) / dst.height() * out.getHeight();
        float r = brushDp * getResources().getDisplayMetrics().density
                * (out.getWidth() / dst.width());
        if (mode == MODE_ERASE) {
            outCanvas.drawCircle(sx, sy, r, erasePaint);
        } else {
            Paint p = keepPaint;
            p.setShader(new BitmapShader(src, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
            Matrix m = new Matrix();
            p.getShader().setLocalMatrix(m);
            outCanvas.drawCircle(sx, sy, r, p);
        }
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        // 棋盘格：表示透明区域
        int grid = 24;
        for (int y = 0; y < getHeight(); y += grid) {
            for (int x = 0; x < getWidth(); x += grid) {
                checkPaint.setColor(((x / grid + y / grid) % 2 == 0) ? 0xFF2A2A34 : 0xFF22222B);
                c.drawRect(x, y, x + grid, y + grid, checkPaint);
            }
        }
        if (out != null) {
            c.drawBitmap(out, null, dst, paint);
        }
        if (mode == MODE_KEEP) {
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2f);
            paint.setColor(0x887C5CFF);
            c.drawRect(dst, paint);
            paint.setStyle(Paint.Style.FILL);
        }
    }

    public void clearResult() {
        if (out != null && src != null) {
            outCanvas.drawBitmap(src, 0, 0, null);
            invalidate();
        }
    }
}
