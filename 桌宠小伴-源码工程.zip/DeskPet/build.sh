#!/bin/bash
# 打出签名好的 APK（需要本机已装 Gradle 6.7.1；没装就用 Android Studio 打开工程点 Build APK）
set -e
cd "$(dirname "$0")"
if command -v gradle >/dev/null 2>&1; then
  gradle assembleRelease
else
  echo "没检测到 gradle，请用 Android Studio 打开本文件夹：Build → Build Bundle(s)/APK(s) → Build APK(s)"
  exit 1
fi
echo "产物：app/build/outputs/apk/release/app-release.apk"
